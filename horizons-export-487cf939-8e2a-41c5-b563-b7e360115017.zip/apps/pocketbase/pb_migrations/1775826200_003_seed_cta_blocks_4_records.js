/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("cta_blocks");

  const record0 = new Record(collection);
    record0.set("type", "learn_more");
    record0.set("title", "Chce\u0161 vedie\u0165 viac?");
    record0.set("button_text", "Prejdi na Knowledge Base");
    record0.set("button_url", "https://kb.drfyto.com");
  try {
    app.save(record0);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record1 = new Record(collection);
    record1.set("type", "shop");
    record1.set("title", "Chce\u0161 to sk\u00fasi\u0165?");
    record1.set("button_text", "Prejdi do Shopu");
    record1.set("button_url", "https://jarmok.shop");
  try {
    app.save(record1);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record2 = new Record(collection);
    record2.set("type", "contact");
    record2.set("title", "Chce\u0161 s nami spolupracova\u0165?");
    record2.set("button_text", "Kontaktuj n\u00e1s");
    record2.set("button_url", "/kontakt");
  try {
    app.save(record2);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record3 = new Record(collection);
    record3.set("type", "experience");
    record3.set("title", "Chce\u0161 to za\u017ei\u0165 na\u017eivo?");
    record3.set("button_text", "Objavuj TopTour");
    record3.set("button_url", "https://toptour.sk");
  try {
    app.save(record3);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }
}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})