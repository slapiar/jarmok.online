/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("sync_state");

  const record0 = new Record(collection);
    record0.set("source", "shop");
    record0.set("source_type", "api");
    record0.set("is_enabled", true);
    record0.set("next_scheduled_check", "2025-01-10");
    record0.set("config", "{'url': 'https://jarmok.shop', 'rss_url': 'https://jarmok.shop/rss', 'api_endpoint': 'https://jarmok.shop/api'}");
  try {
    app.save(record0);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record1 = new Record(collection);
    record1.set("source", "kb");
    record1.set("source_type", "rss");
    record1.set("is_enabled", true);
    record1.set("next_scheduled_check", "2025-01-10");
    record1.set("config", "{'url': 'https://kb.drfyto.com', 'rss_url': 'https://kb.drfyto.com/rss', 'api_endpoint': 'https://kb.drfyto.com/api'}");
  try {
    app.save(record1);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record2 = new Record(collection);
    record2.set("source", "drfyto");
    record2.set("source_type", "rss");
    record2.set("is_enabled", true);
    record2.set("next_scheduled_check", "2025-01-10");
    record2.set("config", "{'url': 'https://drfyto.com', 'rss_url': 'https://drfyto.com/rss', 'api_endpoint': 'https://drfyto.com/api'}");
  try {
    app.save(record2);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record3 = new Record(collection);
    record3.set("source", "toptour");
    record3.set("source_type", "api");
    record3.set("is_enabled", true);
    record3.set("next_scheduled_check", "2025-01-10");
    record3.set("config", "{'url': 'https://toptour.top', 'api_endpoint': 'https://toptour.top/api'}");
  try {
    app.save(record3);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }
}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})