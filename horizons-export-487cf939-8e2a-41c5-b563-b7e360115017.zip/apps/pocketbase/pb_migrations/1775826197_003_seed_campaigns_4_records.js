/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("campaigns");

  const record0 = new Record(collection);
    record0.set("name", "Tajomstvo lesov a l\u00fak");
    record0.set("slug", "tajomstvo-lesov");
    record0.set("description", "Objavuj kr\u00e1su a tajomstv\u00e1 pr\u00edrodn\u00e9ho sveta");
    record0.set("icon", "\ud83c\udf32");
    record0.set("color", "#2d5016");
  try {
    app.save(record0);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record1 = new Record(collection);
    record1.set("name", "K\u00e1va inak");
    record1.set("slug", "kava-inak");
    record1.set("description", "Nov\u00fd poh\u013ead na k\u00e1vu a jej kult\u00faru");
    record1.set("icon", "\u2615");
    record1.set("color", "#6f4e37");
  try {
    app.save(record1);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record2 = new Record(collection);
    record2.set("name", "Bez odpadu");
    record2.set("slug", "bez-odpadu");
    record2.set("description", "Udr\u017eate\u013en\u00fd sp\u00f4sob \u017eivota bez zbyto\u010dn\u00e9ho odpadu");
    record2.set("icon", "\u267b\ufe0f");
    record2.set("color", "#8b7355");
  try {
    app.save(record2);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record3 = new Record(collection);
    record3.set("name", "Sta\u0148 sa partnerom");
    record3.set("slug", "stan-sa-partnerom");
    record3.set("description", "Spolupr\u00e1ca a partnerstvo v ekosyst\u00e9me");
    record3.set("icon", "\ud83e\udd1d");
    record3.set("color", "#5a7c59");
  try {
    app.save(record3);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }
}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})