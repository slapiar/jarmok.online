/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("articles");

  const record0 = new Record(collection);
    record0.set("title", "Tajomstv\u00e1 lesn\u00e9ho ekosyst\u00e9mu");
    record0.set("slug", "tajomstva-lesneho-ekosystemu");
    record0.set("excerpt", "Objavte, ako funguje komplexn\u00fd svet lesn\u00e9ho \u017eivota a jeho vz\u00e1jomn\u00e9 prepojenia.");
    record0.set("content", "Lesn\u00fd ekosyst\u00e9m je jedn\u00fdm z najzlo\u017eitej\u0161\u00edch a najfascinuj\u00facej\u0161\u00edch pr\u00edrodn\u00fdch syst\u00e9mov na Zemi. Ka\u017ed\u00fd strom, ka\u017ed\u00fd \u017eivo\u010d\u00edch a ka\u017ed\u00e1 rastlina hr\u00e1 d\u00f4le\u017eit\u00fa \u00falohu v udr\u017eiavan\u00ed rovnov\u00e1hy. V tomto \u010dl\u00e1nku sa pozrieme na to, ako sa v\u0161etky \u010dasti lesa navz\u00e1jom prep\u00e1jaj\u00fa a ako si pom\u00e1haj\u00fa pri pre\u017eit\u00ed.");
    const record0_campaign_idLookup = app.findFirstRecordByFilter("campaigns", "slug='tajomstvo-lesov'");
    if (!record0_campaign_idLookup) { throw new Error("Lookup failed for campaign_id: no record in 'campaigns' matching \"slug='tajomstvo-lesov'\""); }
    record0.set("campaign_id", record0_campaign_idLookup.id);
  try {
    app.save(record0);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record1 = new Record(collection);
    record1.set("title", "Lesn\u00e9 huby a ich \u00faloha v pr\u00edrode");
    record1.set("slug", "lesne-huby-a-ich-uloga");
    record1.set("excerpt", "Huby s\u00fa nevidite\u013en\u00fdmi in\u017einiermi lesn\u00e9ho ekosyst\u00e9mu. Zistite, pre\u010do s\u00fa tak\u00e9 d\u00f4le\u017eit\u00e9.");
    record1.set("content", "Huby s\u00fa fascinuj\u00face organizmy, ktor\u00e9 zohr\u00e1vaj\u00fa k\u013e\u00fa\u010dov\u00fa \u00falohu v lesnom ekosyst\u00e9me. Rozkladaj\u00fa m\u0155tvu organick\u00fa hmotu, vytv\u00e1raj\u00fa symbiotick\u00e9 vz\u0165ahy s kore\u0148mi stromov a pom\u00e1haj\u00fa pri recykl\u00e1cii \u017eiv\u00edn. Bez h\u00fab by les nemohol existova\u0165 v takej forme, ako ho pozn\u00e1me.");
    const record1_campaign_idLookup = app.findFirstRecordByFilter("campaigns", "slug='tajomstvo-lesov'");
    if (!record1_campaign_idLookup) { throw new Error("Lookup failed for campaign_id: no record in 'campaigns' matching \"slug='tajomstvo-lesov'\""); }
    record1.set("campaign_id", record1_campaign_idLookup.id);
  try {
    app.save(record1);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record2 = new Record(collection);
    record2.set("title", "Hist\u00f3ria a kult\u00fara k\u00e1vovej rastliny");
    record2.set("slug", "historia-kavy");
    record2.set("excerpt", "K\u00e1va m\u00e1 bohat\u00fa hist\u00f3riu, ktor\u00e1 siaha do staroveku. Pozrite sa, ako sa stala jedn\u00fdm z najob\u013e\u00fabenej\u0161\u00edch n\u00e1pojov sveta.");
    record2.set("content", "K\u00e1va nie je len n\u00e1poj, je to kult\u00fara, hist\u00f3ria a v\u00e1\u0161e\u0148. Jej cesta z Eti\u00f3pie do cel\u00e9ho sveta je pln\u00e1 zauj\u00edmav\u00fdch pr\u00edbehov. Ka\u017ed\u00e1 \u0161\u00e1lka k\u00e1vy m\u00e1 svoju vlastn\u00fa hist\u00f3riu a pr\u00edbeh o \u013eu\u010foch, ktor\u00ed ju pestuj\u00fa, sprac\u00favaj\u00fa a pripravuj\u00fa.");
    const record2_campaign_idLookup = app.findFirstRecordByFilter("campaigns", "slug='kava-inak'");
    if (!record2_campaign_idLookup) { throw new Error("Lookup failed for campaign_id: no record in 'campaigns' matching \"slug='kava-inak'\""); }
    record2.set("campaign_id", record2_campaign_idLookup.id);
  try {
    app.save(record2);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record3 = new Record(collection);
    record3.set("title", "Ako si vybra\u0165 spr\u00e1vnu k\u00e1vu pre v\u00e1s");
    record3.set("slug", "ako-vybrat-kavu");
    record3.set("excerpt", "Sprievodca v\u00fdberom spr\u00e1vnej k\u00e1vovej odrody a sp\u00f4sobu pr\u00edpravy pod\u013ea va\u0161ich preferenci\u00ed.");
    record3.set("content", "V\u00fdber spr\u00e1vnej k\u00e1vovej odrody m\u00f4\u017ee by\u0165 zlo\u017eit\u00fd, ale s na\u0161\u00edm sprievodcom to bude jednoduch\u00e9. Existuj\u00fa stovky r\u00f4znych odr\u00f4d, ka\u017ed\u00e1 s vlastn\u00fdm charakterom a chu\u0165ou. Nau\u010d\u00edme v\u00e1s, ako rozpozna\u0165 kvalitu a ako si vybra\u0165 k\u00e1vu, ktor\u00e1 v\u00e1m bude chutie\u0165.");
    const record3_campaign_idLookup = app.findFirstRecordByFilter("campaigns", "slug='kava-inak'");
    if (!record3_campaign_idLookup) { throw new Error("Lookup failed for campaign_id: no record in 'campaigns' matching \"slug='kava-inak'\""); }
    record3.set("campaign_id", record3_campaign_idLookup.id);
  try {
    app.save(record3);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record4 = new Record(collection);
    record4.set("title", "Za\u010dnite s bezodpadov\u00fdm \u017eivotom");
    record4.set("slug", "zaciname-bez-odpadu");
    record4.set("excerpt", "Praktick\u00e9 tipy a triky, ako za\u010da\u0165 s bezodpadov\u00fdm \u017eivotom bez toho, aby ste sa c\u00edtili pre\u0165a\u017een\u00ed.");
    record4.set("content", "Bezodpadov\u00fd \u017eivotn\u00fd \u0161t\u00fdl sa zd\u00e1 by\u0165 n\u00e1ro\u010dn\u00fd, ale v skuto\u010dnosti je to jednoduch\u0161ie, ako si mysl\u00edte. Za\u010dnite mal\u00fdmi krokmi: zn\u00ed\u017ete spotrebu plastov, kompostujte organick\u00fd odpad a kupujte produkty bez zbyto\u010dn\u00e9ho balenia. Ka\u017ed\u00fd mal\u00fd krok sa po\u010d\u00edta a prispiev\u00e1 k v\u00e4\u010d\u0161ej zmene.");
    const record4_campaign_idLookup = app.findFirstRecordByFilter("campaigns", "slug='bez-odpadu'");
    if (!record4_campaign_idLookup) { throw new Error("Lookup failed for campaign_id: no record in 'campaigns' matching \"slug='bez-odpadu'\""); }
    record4.set("campaign_id", record4_campaign_idLookup.id);
  try {
    app.save(record4);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record5 = new Record(collection);
    record5.set("title", "Udr\u017eate\u013en\u00e9 alternat\u00edvy k be\u017en\u00fdm produktom");
    record5.set("slug", "udrzatelne-alternativy");
    record5.set("excerpt", "Objavte ekologick\u00e9 a udr\u017eate\u013en\u00e9 alternat\u00edvy k produktom, ktor\u00e9 pou\u017e\u00edvate ka\u017ed\u00fd de\u0148.");
    record5.set("content", "Existuje mnoho udr\u017eate\u013en\u00fdch alternat\u00edv k produktom, ktor\u00e9 pou\u017e\u00edvame ka\u017ed\u00fd de\u0148. Od bambusov\u00fdch zubn\u00fdch kief po kompostovate\u013en\u00e9 vreck\u00e1, mo\u017enosti s\u00fa nekone\u010dn\u00e9. V tomto \u010dl\u00e1nku v\u00e1m uk\u00e1\u017eeme, kde ich n\u00e1js\u0165 a ako ich pou\u017e\u00edva\u0165.");
    const record5_campaign_idLookup = app.findFirstRecordByFilter("campaigns", "slug='bez-odpadu'");
    if (!record5_campaign_idLookup) { throw new Error("Lookup failed for campaign_id: no record in 'campaigns' matching \"slug='bez-odpadu'\""); }
    record5.set("campaign_id", record5_campaign_idLookup.id);
  try {
    app.save(record5);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record6 = new Record(collection);
    record6.set("title", "Ako sa sta\u0165 partnerom v na\u0161om ekosyst\u00e9me");
    record6.set("slug", "stante-sa-partnerom");
    record6.set("excerpt", "V\u0161etko, \u010do potrebujete vedie\u0165 o tom, ako sa zapoji\u0165 do n\u00e1\u0161ho rast\u00faceho partnersk\u00e9ho programu.");
    record6.set("content", "H\u013ead\u00e1me partnerov, ktor\u00ed zdie\u013eaj\u00fa na\u0161u v\u00edziu udr\u017eate\u013enosti a inov\u00e1ci\u00ed. \u010ci ste podnikate\u013e, influencer alebo organiz\u00e1cia, m\u00e1me pre v\u00e1s miesto v na\u0161om ekosyst\u00e9me. Nau\u010d\u00edme v\u00e1s, ako sa zapoji\u0165 a ako m\u00f4\u017eeme spolu r\u00e1s\u0165.");
    const record6_campaign_idLookup = app.findFirstRecordByFilter("campaigns", "slug='stan-sa-partnerom'");
    if (!record6_campaign_idLookup) { throw new Error("Lookup failed for campaign_id: no record in 'campaigns' matching \"slug='stan-sa-partnerom'\""); }
    record6.set("campaign_id", record6_campaign_idLookup.id);
  try {
    app.save(record6);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record7 = new Record(collection);
    record7.set("title", "Pr\u00edbehy na\u0161ich partnerov");
    record7.set("slug", "pribehy-partnerov");
    record7.set("excerpt", "In\u0161pirat\u00edvne pr\u00edbehy od \u013eud\u00ed a organiz\u00e1ci\u00ed, ktor\u00e9 sa stali na\u0161imi partnermi.");
    record7.set("content", "Na\u0161i partneri s\u00fa srdcom n\u00e1\u0161ho ekosyst\u00e9mu. Ka\u017ed\u00fd z nich m\u00e1 svoju vlastn\u00fa hist\u00f3riu a v\u00edziu. V tomto \u010dl\u00e1nku sa dozviete, ako sa stali na\u0161imi partnermi a ako spolu vytv\u00e1rame pozit\u00edvnu zmenu v svete.");
    const record7_campaign_idLookup = app.findFirstRecordByFilter("campaigns", "slug='stan-sa-partnerom'");
    if (!record7_campaign_idLookup) { throw new Error("Lookup failed for campaign_id: no record in 'campaigns' matching \"slug='stan-sa-partnerom'\""); }
    record7.set("campaign_id", record7_campaign_idLookup.id);
  try {
    app.save(record7);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record8 = new Record(collection);
    record8.set("title", "Bud\u00facnos\u0165 partnerstva a spolupr\u00e1ce");
    record8.set("slug", "buducnost-partnerstva");
    record8.set("excerpt", "Pozrite sa na to, ako sa vyv\u00edja partnerstvo a ak\u00e9 s\u00fa bud\u00face pl\u00e1ny pre n\u00e1\u0161 ekosyst\u00e9m.");
    record8.set("content", "Bud\u00facnos\u0165 je vzru\u0161uj\u00faca. Pl\u00e1nujeme roz\u0161\u00edri\u0165 n\u00e1\u0161 ekosyst\u00e9m a priv\u00edta\u0165 \u010fal\u0161\u00edch partnerov. Spolu budeme vytv\u00e1ra\u0165 inovat\u00edvne rie\u0161enia a budova\u0165 komunitu, ktor\u00e1 sa star\u00e1 o plan\u00e9tu a o sebe navz\u00e1jom.");
    const record8_campaign_idLookup = app.findFirstRecordByFilter("campaigns", "slug='stan-sa-partnerom'");
    if (!record8_campaign_idLookup) { throw new Error("Lookup failed for campaign_id: no record in 'campaigns' matching \"slug='stan-sa-partnerom'\""); }
    record8.set("campaign_id", record8_campaign_idLookup.id);
  try {
    app.save(record8);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record9 = new Record(collection);
    record9.set("title", "Lesn\u00e9 terapia a jej zdravotn\u00e9 v\u00fdhody");
    record9.set("slug", "lesna-terapia");
    record9.set("excerpt", "Zistite, ako pobyt v lese m\u00f4\u017ee zlep\u0161i\u0165 va\u0161u fyzick\u00fa a ment\u00e1lnu zdravie.");
    record9.set("content", "Lesn\u00e1 terapia, zn\u00e1ma aj ako forest bathing, je starobyl\u00e1 prax, ktor\u00e1 sa v posledn\u00fdch rokoch stala ve\u013emi popul\u00e1rna. Pobyt v lese m\u00e1 dok\u00e1zan\u00e9 zdravotn\u00e9 v\u00fdhody: zni\u017euje stres, posil\u0148uje imunitn\u00fd syst\u00e9m a zlep\u0161uje n\u00e1ladu. V\u0161etko, \u010do potrebujete, je les a chv\u00ed\u013ea \u010dasu.");
    const record9_campaign_idLookup = app.findFirstRecordByFilter("campaigns", "slug='tajomstvo-lesov'");
    if (!record9_campaign_idLookup) { throw new Error("Lookup failed for campaign_id: no record in 'campaigns' matching \"slug='tajomstvo-lesov'\""); }
    record9.set("campaign_id", record9_campaign_idLookup.id);
  try {
    app.save(record9);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }
}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})