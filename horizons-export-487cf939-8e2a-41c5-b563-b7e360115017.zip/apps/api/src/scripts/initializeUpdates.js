import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const SOURCES = [
  {
    source: 'shop',
    source_type: 'api',
    config: {
      url: 'https://jarmok.shop',
      rss_url: 'https://jarmok.shop/rss',
      api_endpoint: 'https://jarmok.shop/api',
      timeout_ms: 30000,
    },
  },
  {
    source: 'kb',
    source_type: 'rss',
    config: {
      url: 'https://kb.drfyto.com',
      rss_url: 'https://kb.drfyto.com/rss',
      api_endpoint: 'https://kb.drfyto.com/api',
      timeout_ms: 30000,
    },
  },
  {
    source: 'drfyto',
    source_type: 'rss',
    config: {
      url: 'https://drfyto.com',
      rss_url: 'https://drfyto.com/rss',
      api_endpoint: 'https://drfyto.com/api',
      timeout_ms: 30000,
    },
  },
  {
    source: 'toptour',
    source_type: 'api',
    config: {
      url: 'https://toptour.top',
      api_endpoint: 'https://toptour.top/api',
      timeout_ms: 30000,
    },
  },
];

/**
 * Initialize the Updates module
 * Creates sync_state records for all sources if they don't exist
 */
export async function initializeUpdates() {
  try {
    logger.info('Initializing Updates module...');

    const now = new Date().toISOString();

    for (const sourceConfig of SOURCES) {
      try {
        // Check if sync_state record exists
        const existing = await pb.collection('sync_state').getFirstListItem(
          `source = "${sourceConfig.source}"`,
          { requestKey: null }
        ).catch(() => null);

        if (!existing) {
          // Create new sync_state record
          await pb.collection('sync_state').create(
            {
              source: sourceConfig.source,
              source_type: sourceConfig.source_type,
              is_enabled: true,
              next_scheduled_check: now,
              last_successful_check: null,
              last_processed_timestamp: null,
              last_processed_fingerprints: [],
              items_new: 0,
              items_updated: 0,
              items_skipped: 0,
              fetch_status: 'pending',
              error_message: null,
              config: JSON.stringify(sourceConfig.config),
            },
            { requestKey: null }
          );
          logger.info(`Created sync_state for source: ${sourceConfig.source}`);
        } else {
          logger.info(`sync_state already exists for source: ${sourceConfig.source}`);
        }
      } catch (error) {
        logger.error(`Failed to initialize source ${sourceConfig.source}: ${error.message}`);
      }
    }

    logger.info('Updates module initialized successfully');
  } catch (error) {
    logger.error(`Failed to initialize Updates module: ${error.message}`);
    throw error;
  }
}