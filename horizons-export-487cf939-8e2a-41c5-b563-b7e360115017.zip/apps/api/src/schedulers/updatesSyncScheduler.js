import cron from 'node-cron';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';
import { syncSource } from '../services/syncService.js';
import {
  getSourceConfig,
  isSourceEnabled,
  isEndpointPlaceholder,
} from '../config/sources.config.js';

let scheduledJob = null;

/**
 * Initialize the updates sync scheduler
 * Runs every 6 hours
 */
export function initializeScheduler() {
  logger.info('Initializing Updates Sync Scheduler...');

  // Schedule job to run every 6 hours: 0 */6 * * *
  scheduledJob = cron.schedule('0 */6 * * *', async () => {
    logger.info('Starting scheduled sync job...');
    await runSyncJob();
  });

  logger.info('Updates Sync Scheduler initialized (runs every 6 hours)');
}

/**
 * Run the sync job for all enabled sources
 */
async function runSyncJob() {
  try {
    // Fetch all enabled sources
    const syncStates = await pb.collection('sync_state').getFullList({
      filter: 'is_enabled = true',
      requestKey: null,
    });

    logger.info(`Running sync for ${syncStates.length} enabled sources`);

    const results = [];

    // Sync each source
    for (const syncState of syncStates) {
      try {
        const source = syncState.source;
        const config = getSourceConfig(source);

        // Check if source is enabled
        if (!isSourceEnabled(source)) {
          logger.info(`⏸️ ${config.name} je dočasne vypnutý — preskakujem`);
          continue;
        }

        // Check for placeholder endpoints
        const hasPlaceholders = Object.keys(config.endpoints).some((endpointType) =>
          isEndpointPlaceholder(source, endpointType)
        );

        if (hasPlaceholders) {
          logger.warn(
            `⚠️ ${config.name} má placeholder endpointy — čakáme na potvrdenie reálnych URL`
          );
        }

        // Log sync start
        logger.info(`🔄 Syncing ${config.name}...`);

        const result = await syncSource(source);

        // Log sync results
        logger.info(
          `✓ ${config.name}: ${result.itemsCreated} nových, ${result.itemsUpdated} aktualizovaných, ${result.itemsSkipped} preskočených`
        );

        results.push({
          source,
          ...result,
        });
      } catch (error) {
        const source = syncState.source;
        const config = getSourceConfig(source);
        logger.error(`✗ ${config.name} sync zlyhalo: ${error.message}`);
        results.push({
          source,
          success: false,
          error: error.message,
        });
        // Continue with next source instead of breaking
      }
    }

    // Update next_scheduled_check for all sources
    const nextCheck = new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString();
    for (const syncState of syncStates) {
      try {
        await pb.collection('sync_state').update(
          syncState.id,
          {
            next_scheduled_check: nextCheck,
          },
          { requestKey: null }
        );
      } catch (error) {
        logger.error(`Failed to update next_scheduled_check for ${syncState.source}: ${error.message}`);
      }
    }

    logger.info(`Scheduled sync job completed. Results: ${JSON.stringify(results)}`);
  } catch (error) {
    logger.error(`Scheduled sync job failed: ${error.message}`);
  }
}

/**
 * Stop the scheduler
 */
export function stopScheduler() {
  if (scheduledJob) {
    scheduledJob.stop();
    logger.info('Updates Sync Scheduler stopped');
  }
}