import { Router } from 'express';
import healthCheck from './health-check.js';
import updatesRouter from './updates.js';

const router = Router();

export default () => {
    router.get('/health', healthCheck);
    router.use('/updates', updatesRouter);

    return router;
};