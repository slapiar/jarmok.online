import express from 'express';
import logger from '../utils/logger.js';
import { syncSource } from '../services/syncService.js';
import pb from '../utils/pocketbaseClient.js';

const router = express.Router();

const VALID_SOURCES = ['shop', 'kb', 'drfyto', 'toptour'];

/**
 * POST /sync
 * Trigger synchronization of all enabled sources
 */
router.post('/sync', async (req, res) => {
  logger.info('Manual sync triggered for all sources');

  const syncStates = await pb.collection('sync_state').getFullList({
    filter: 'is_enabled = true',
    requestKey: null,
  });

  const results = [];

  for (const syncState of syncStates) {
    try {
      const result = await syncSource(syncState.source);
      results.push({
        source: syncState.source,
        ...result,
      });
    } catch (error) {
      logger.error(`Sync failed for ${syncState.source}: ${error.message}`);
      results.push({
        source: syncState.source,
        success: false,
        error: error.message,
      });
    }
  }

  res.json({
    success: results.every((r) => r.success),
    results,
  });
});

/**
 * GET /sync-state
 * Get current sync state for all sources
 */
router.get('/sync-state', async (req, res) => {
  const syncStates = await pb.collection('sync_state').getFullList({
    requestKey: null,
  });

  res.json(syncStates);
});

/**
 * GET /logs
 * Get recent sync logs (last 50 records)
 */
router.get('/logs', async (req, res) => {
  const logs = await pb.collection('sync_logs').getFullList({
    sort: '-created',
    limit: 50,
    requestKey: null,
  });

  res.json(logs);
});

/**
 * POST /sync/:source
 * Trigger synchronization of specific source
 */
router.post('/sync/:source', async (req, res) => {
  const { source } = req.params;

  if (!VALID_SOURCES.includes(source)) {
    return res.status(400).json({
      error: `Invalid source. Must be one of: ${VALID_SOURCES.join(', ')}`,
    });
  }

  logger.info(`Manual sync triggered for source: ${source}`);

  const result = await syncSource(source);

  res.json({
    success: result.success,
    result,
  });
});

export default router;