import axios from 'axios';
import logger from '../utils/logger.js';
import {
  getSourceConfig,
  isSourceEnabled,
  isEndpointPlaceholder,
  getEndpointConfig,
} from '../config/sources.config.js';

const RETRY_DELAY_MS = 5000;

/**
 * Fetch data from jarmok.shop
 * Tries: API endpoint → RSS → Scraping
 */
export async function fetchShop() {
  const source = 'shop';
  const config = getSourceConfig(source);

  if (!isSourceEnabled(source)) {
    logger.info(`⏸️ Jarmok Shop je dočasne vypnutý — preskakujem`);
    return null;
  }

  const sources = [
    {
      type: 'api',
      name: 'API',
      fetch: async () => {
        const endpoint = getEndpointConfig(source, 'api');
        if (isEndpointPlaceholder(source, 'api')) {
          logger.warn(
            `⚠️ Jarmok Shop API je placeholder — čakáme na potvrdenie reálneho API`
          );
        }
        logger.debug(`ℹ️ Jarmok Shop: Pokúšam sa API endpoint (${endpoint.url})`);
        const response = await axios.get(endpoint.url, {
          timeout: endpoint.timeout,
        });
        return response.data;
      },
    },
    {
      type: 'rss',
      name: 'RSS',
      fetch: async () => {
        const endpoint = getEndpointConfig(source, 'rss');
        if (isEndpointPlaceholder(source, 'rss')) {
          logger.warn(
            `⚠️ Jarmok Shop RSS je placeholder — čakáme na potvrdenie reálneho RSS`
          );
        }
        logger.debug(`ℹ️ Jarmok Shop: Pokúšam sa RSS feed (${endpoint.url})`);
        const response = await axios.get(endpoint.url, {
          timeout: endpoint.timeout,
        });
        return response.data;
      },
    },
    {
      type: 'scraping',
      name: 'Scraping',
      fetch: async () => {
        const endpoint = getEndpointConfig(source, 'scraping');
        logger.warn(
          `⚠️ Jarmok Shop scraping nie je implementovaný — TODO: doplniť po overení zdroja`
        );
        logger.debug(`ℹ️ Jarmok Shop: Pokúšam sa scraping (${endpoint.url})`);
        const response = await axios.get(endpoint.url, {
          timeout: endpoint.timeout,
        });
        return response.data;
      },
    },
  ];

  return attemptFetch(source, 'Jarmok Shop', sources);
}

/**
 * Fetch data from kb.drfyto.com
 * Tries: RSS → API → Scraping
 */
export async function fetchKB() {
  const source = 'kb';
  const config = getSourceConfig(source);

  if (!isSourceEnabled(source)) {
    logger.info(`⏸️ DrFyto Knowledge Base je dočasne vypnutá — preskakujem`);
    return null;
  }

  const sources = [
    {
      type: 'rss',
      name: 'RSS',
      fetch: async () => {
        const endpoint = getEndpointConfig(source, 'rss');
        if (isEndpointPlaceholder(source, 'rss')) {
          logger.warn(
            `⚠️ DrFyto KB RSS je placeholder — čakáme na potvrdenie reálneho RSS`
          );
        }
        logger.debug(`ℹ️ DrFyto KB: Pokúšam sa RSS feed (${endpoint.url})`);
        const response = await axios.get(endpoint.url, {
          timeout: endpoint.timeout,
        });
        return response.data;
      },
    },
    {
      type: 'api',
      name: 'API',
      fetch: async () => {
        const endpoint = getEndpointConfig(source, 'api');
        if (isEndpointPlaceholder(source, 'api')) {
          logger.warn(
            `⚠️ DrFyto KB API je placeholder — čakáme na potvrdenie reálneho API`
          );
        }
        logger.debug(`ℹ️ DrFyto KB: Pokúšam sa API endpoint (${endpoint.url})`);
        const response = await axios.get(endpoint.url, {
          timeout: endpoint.timeout,
        });
        return response.data;
      },
    },
    {
      type: 'scraping',
      name: 'Scraping',
      fetch: async () => {
        const endpoint = getEndpointConfig(source, 'scraping');
        logger.warn(
          `⚠️ DrFyto KB scraping nie je implementovaný — TODO: doplniť po overení zdroja`
        );
        logger.debug(`ℹ️ DrFyto KB: Pokúšam sa scraping (${endpoint.url})`);
        const response = await axios.get(endpoint.url, {
          timeout: endpoint.timeout,
        });
        return response.data;
      },
    },
  ];

  return attemptFetch(source, 'DrFyto Knowledge Base', sources);
}

/**
 * Fetch data from drfyto.com
 * Tries: RSS → API → Scraping
 */
export async function fetchDrfyto() {
  const source = 'drfyto';
  const config = getSourceConfig(source);

  if (!isSourceEnabled(source)) {
    logger.info(`⏸️ DrFyto Main je dočasne vypnutý — preskakujem`);
    return null;
  }

  const sources = [
    {
      type: 'rss',
      name: 'RSS',
      fetch: async () => {
        const endpoint = getEndpointConfig(source, 'rss');
        if (isEndpointPlaceholder(source, 'rss')) {
          logger.warn(
            `⚠️ DrFyto Main RSS je placeholder — čakáme na potvrdenie reálneho RSS`
          );
        }
        logger.debug(`ℹ️ DrFyto Main: Pokúšam sa RSS feed (${endpoint.url})`);
        const response = await axios.get(endpoint.url, {
          timeout: endpoint.timeout,
        });
        return response.data;
      },
    },
    {
      type: 'api',
      name: 'API',
      fetch: async () => {
        const endpoint = getEndpointConfig(source, 'api');
        if (isEndpointPlaceholder(source, 'api')) {
          logger.warn(
            `⚠️ DrFyto Main API je placeholder — čakáme na potvrdenie reálneho API`
          );
        }
        logger.debug(`ℹ️ DrFyto Main: Pokúšam sa API endpoint (${endpoint.url})`);
        const response = await axios.get(endpoint.url, {
          timeout: endpoint.timeout,
        });
        return response.data;
      },
    },
    {
      type: 'scraping',
      name: 'Scraping',
      fetch: async () => {
        const endpoint = getEndpointConfig(source, 'scraping');
        logger.warn(
          `⚠️ DrFyto Main scraping nie je implementovaný — TODO: doplniť po overení zdroja`
        );
        logger.debug(`ℹ️ DrFyto Main: Pokúšam sa scraping (${endpoint.url})`);
        const response = await axios.get(endpoint.url, {
          timeout: endpoint.timeout,
        });
        return response.data;
      },
    },
  ];

  return attemptFetch(source, 'DrFyto Main', sources);
}

/**
 * Fetch data from toptour.top
 * Tries: API → Scraping
 */
export async function fetchTopTour() {
  const source = 'toptour';
  const config = getSourceConfig(source);

  if (!isSourceEnabled(source)) {
    logger.info(`⏸️ TopTour Events je dočasne vypnutý — preskakujem`);
    return null;
  }

  const sources = [
    {
      type: 'api',
      name: 'API',
      fetch: async () => {
        const endpoint = getEndpointConfig(source, 'api');
        if (isEndpointPlaceholder(source, 'api')) {
          logger.warn(
            `⚠️ TopTour API je placeholder — čakáme na potvrdenie reálneho API`
          );
        }
        logger.debug(`ℹ️ TopTour: Pokúšam sa API endpoint (${endpoint.url})`);
        const response = await axios.get(endpoint.url, {
          timeout: endpoint.timeout,
        });
        return response.data;
      },
    },
    {
      type: 'scraping',
      name: 'Scraping',
      fetch: async () => {
        const endpoint = getEndpointConfig(source, 'scraping');
        logger.warn(
          `⚠️ TopTour scraping nie je implementovaný — TODO: doplniť po overení zdroja`
        );
        logger.debug(`ℹ️ TopTour: Pokúšam sa scraping (${endpoint.url})`);
        const response = await axios.get(endpoint.url, {
          timeout: endpoint.timeout,
        });
        return response.data;
      },
    },
  ];

  return attemptFetch(source, 'TopTour Events', sources);
}

/**
 * Attempt to fetch from multiple sources with retry logic
 */
async function attemptFetch(source, sourceName, sources) {
  for (const sourceConfig of sources) {
    try {
      logger.info(`ℹ️ ${sourceName}: Pokúšam sa ${sourceConfig.name}...`);
      const data = await sourceConfig.fetch();
      logger.info(`✓ ${sourceName}: Úspešne načítané (${sourceConfig.name})`);
      return data;
    } catch (error) {
      logger.warn(
        `✗ ${sourceName}: Zlyhalo načítanie (${sourceConfig.name}): ${error.message}`
      );

      try {
        await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY_MS));
        logger.info(`ℹ️ ${sourceName}: Opakovanie ${sourceConfig.name}...`);
        const data = await sourceConfig.fetch();
        logger.info(
          `✓ ${sourceName}: Úspešne načítané pri opakovaní (${sourceConfig.name})`
        );
        return data;
      } catch (retryError) {
        logger.warn(
          `✗ ${sourceName}: Opakovanie zlyhalo (${sourceConfig.name}): ${retryError.message}`
        );
      }
    }
  }

  throw new Error(`✗ ${sourceName}: Zlyhalo načítanie po všetkých pokusoch`);
}