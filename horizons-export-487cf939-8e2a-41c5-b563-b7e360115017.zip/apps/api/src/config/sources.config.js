/**
 * Sources Configuration
 * Centralized configuration for all data sources (shop, kb, drfyto, toptour)
 * Each source has enabled flag and endpoint configurations with status tracking
 */

const SOURCES_CONFIG = {
  shop: {
    name: 'Jarmok Shop',
    enabled: true,
    sourceType: 'api',
    endpoints: {
      api: {
        url: 'https://jarmok.shop/api/products',
        timeout: 30000,
        status: 'placeholder',
      },
      rss: {
        url: 'https://jarmok.shop/rss',
        timeout: 30000,
        status: 'placeholder',
      },
      scraping: {
        url: 'https://jarmok.shop',
        timeout: 30000,
        status: 'placeholder',
      },
    },
  },
  kb: {
    name: 'DrFyto Knowledge Base',
    enabled: true,
    sourceType: 'rss',
    endpoints: {
      rss: {
        url: 'https://kb.drfyto.com/feed.xml',
        timeout: 30000,
        status: 'placeholder',
      },
      api: {
        url: 'https://kb.drfyto.com/wp-json/updates/v1/items?post_type=post',
        timeout: 30000,
        status: 'active',
      },
      scraping: {
        url: 'https://kb.drfyto.com',
        timeout: 30000,
        status: 'not_implemented',
      },
    },
  },
  drfyto: {
    name: 'DrFyto Main',
    enabled: true,
    sourceType: 'rss',
    endpoints: {
      rss: {
        url: 'https://drfyto.com/rss',
        timeout: 30000,
        status: 'placeholder',
      },
      api: {
        url: 'https://drfyto.com/api/articles',
        timeout: 30000,
        status: 'placeholder',
      },
      scraping: {
        url: 'https://drfyto.com',
        timeout: 30000,
        status: 'placeholder',
      },
    },
  },
  toptour: {
    name: 'TopTour Events',
    enabled: true,
    sourceType: 'api',
    endpoints: {
      api: {
        url: 'https://toptour.top/api/events',
        timeout: 30000,
        status: 'placeholder',
      },
      scraping: {
        url: 'https://toptour.top',
        timeout: 30000,
        status: 'placeholder',
      },
    },
  },
};

/**
 * Get configuration for a specific source
 * @param {string} source - Source identifier (shop, kb, drfyto, toptour)
 * @returns {object|null} Source configuration object or null if not found
 */
export function getSourceConfig(source) {
  return SOURCES_CONFIG[source] || null;
}

/**
 * Check if a source is enabled
 * @param {string} source - Source identifier
 * @returns {boolean} True if source is enabled, false otherwise
 */
export function isSourceEnabled(source) {
  const config = getSourceConfig(source);
  return config ? config.enabled : false;
}

/**
 * Check if an endpoint is a placeholder (temporary, awaiting real API confirmation)
 * @param {string} source - Source identifier
 * @param {string} endpointType - Endpoint type (api, rss, scraping)
 * @returns {boolean} True if endpoint is placeholder, false if confirmed
 */
export function isEndpointPlaceholder(source, endpointType) {
  const config = getSourceConfig(source);
  if (!config || !config.endpoints[endpointType]) {
    return true;
  }
  return config.endpoints[endpointType].status === 'placeholder';
}

/**
 * Get configuration for a specific endpoint
 * @param {string} source - Source identifier
 * @param {string} endpointType - Endpoint type (api, rss, scraping)
 * @returns {object|null} Endpoint configuration object or null if not found
 */
export function getEndpointConfig(source, endpointType) {
  const config = getSourceConfig(source);
  if (!config || !config.endpoints[endpointType]) {
    return null;
  }
  return config.endpoints[endpointType];
}

export default SOURCES_CONFIG;