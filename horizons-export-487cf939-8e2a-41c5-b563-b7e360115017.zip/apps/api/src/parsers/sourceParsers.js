import logger from '../utils/logger.js';

/**
 * Bezpečné skrátenie textu pre log.
 */
function safePreview(data, maxLength = 200) {
  try {
    const text =
      typeof data === 'string' ? data : JSON.stringify(data);
    return text.length > maxLength ? `${text.substring(0, maxLength)}...` : text;
  } catch (error) {
    return '[Nepodarilo sa vytvoriť preview dát]';
  }
}

/**
 * Pomocná funkcia na vytiahnutie XML tagu z RSS položky.
 */
export function extractXmlTag(xml, tagName) {
  if (!xml || !tagName) return '';
  const regex = new RegExp(`<${tagName}>([\\s\\S]*?)<\\/${tagName}>`, 'i');
  const match = xml.match(regex);
  return match ? match[1].trim() : '';
}

/**
 * Parser pre Jarmok Shop.
 * Podporuje:
 * 1. Nový JSON formát s data.items
 * 2. Starší JSON formát s data.products
 * 3. RSS XML
 */
export function parseShopData(data) {
  // 1. Nový JSON endpoint / items
  if (data && Array.isArray(data.items)) {
    return data.items.map((item) => ({
      source_id: item.source_id,
      title: item.title,
      description: item.description || '',
      url: item.url,
      updated_at: item.updated_at || new Date().toISOString(),
      image: item.image || null,
      entity_type: item.entity_type || 'product',
      change_type: item.change_type || 'new',
      taxonomies: item.taxonomies || {},
      source_type: item.source_type || 'product',
    }));
  }

  // 2. Starší JSON formát / products
  if (data && Array.isArray(data.products)) {
    return data.products.map((product) => ({
      source_id: product.id || product.source_id,
      title: product.name || product.title,
      description: product.description || product.excerpt || '',
      url: product.url || product.link,
      updated_at: product.updated_at || product.published_at || new Date().toISOString(),
      image: product.image || null,
      entity_type: product.entity_type || 'product',
      change_type: product.change_type || 'new',
      taxonomies: product.taxonomies || {},
      source_type: product.source_type || 'product',
    }));
  }

  // 3. RSS XML
  if (typeof data === 'string' && data.includes('<item>')) {
    const itemMatches = data.match(/<item>([\s\S]*?)<\/item>/g) || [];

    return itemMatches.map((itemXml) => ({
      source_id: extractXmlTag(itemXml, 'guid') || extractXmlTag(itemXml, 'link'),
      title: extractXmlTag(itemXml, 'title'),
      description: extractXmlTag(itemXml, 'description'),
      url: extractXmlTag(itemXml, 'link'),
      updated_at: extractXmlTag(itemXml, 'pubDate') || new Date().toISOString(),
      image: extractXmlTag(itemXml, 'image') || null,
      entity_type: 'product',
      change_type: 'new',
      taxonomies: {},
      source_type: 'rss',
    }));
  }

  logger.warn(
    `⚠️ Shop parser vrátil neočakávanú štruktúru. Dostali: ${safePreview(data)}`
  );

  return [];
}

/**
 * Parser pre KB.
 * Podporuje:
 * 1. Nový JSON formát s data.items
 * 2. Starší JSON formát s data.articles
 * 3. RSS XML
 */
export function parseKBData(data) {
  // 1. Nový vlastný WP endpoint
  if (data && Array.isArray(data.items)) {
    return data.items.map((item) => ({
      source_id: item.source_id,
      title: item.title,
      description: item.description || '',
      url: item.url,
      updated_at: item.updated_at || new Date().toISOString(),
      image: item.image || null,
      entity_type: item.entity_type || 'article',
      change_type: item.change_type || 'new',
      taxonomies: item.taxonomies || {},
      source_type: item.source_type || 'post',
    }));
  }

  // 2. Starší JSON formát
  if (data && Array.isArray(data.articles)) {
    return data.articles.map((article) => ({
      source_id: article.id || article.source_id,
      title: article.title,
      description: article.description || article.excerpt || '',
      url: article.url || article.link,
      updated_at: article.updated_at || article.published_at || new Date().toISOString(),
      image: article.image || null,
      entity_type: article.entity_type || 'article',
      change_type: article.change_type || 'new',
      taxonomies: article.taxonomies || {},
      source_type: article.source_type || 'article',
    }));
  }

  // 3. RSS XML
  if (typeof data === 'string' && data.includes('<item>')) {
    const itemMatches = data.match(/<item>([\s\S]*?)<\/item>/g) || [];

    return itemMatches.map((itemXml) => ({
      source_id: extractXmlTag(itemXml, 'guid') || extractXmlTag(itemXml, 'link'),
      title: extractXmlTag(itemXml, 'title'),
      description: extractXmlTag(itemXml, 'description'),
      url: extractXmlTag(itemXml, 'link'),
      updated_at: extractXmlTag(itemXml, 'pubDate') || new Date().toISOString(),
      image: extractXmlTag(itemXml, 'image') || null,
      entity_type: 'article',
      change_type: 'new',
      taxonomies: {},
      source_type: 'rss',
    }));
  }

  logger.warn(
    `⚠️ KB parser vrátil neočakávanú štruktúru. Dostali: ${safePreview(data)}`
  );

  return [];
}

/**
 * Parser pre DrFyto main.
 * Podporuje:
 * 1. Nový JSON formát s data.items
 * 2. Starší JSON formát s data.articles
 * 3. RSS XML
 */
export function parseDrfytoData(data) {
  // 1. Nový JSON endpoint / items
  if (data && Array.isArray(data.items)) {
    return data.items.map((item) => ({
      source_id: item.source_id,
      title: item.title,
      description: item.description || '',
      url: item.url,
      updated_at: item.updated_at || new Date().toISOString(),
      image: item.image || null,
      entity_type: item.entity_type || 'article',
      change_type: item.change_type || 'new',
      taxonomies: item.taxonomies || {},
      source_type: item.source_type || 'post',
    }));
  }

  // 2. Starší JSON formát / articles
  if (data && Array.isArray(data.articles)) {
    return data.articles.map((article) => ({
      source_id: article.id || article.source_id,
      title: article.title,
      description: article.description || article.excerpt || '',
      url: article.url || article.link,
      updated_at: article.updated_at || article.published_at || new Date().toISOString(),
      image: article.image || null,
      entity_type: article.entity_type || 'article',
      change_type: article.change_type || 'new',
      taxonomies: article.taxonomies || {},
      source_type: article.source_type || 'article',
    }));
  }

  // 3. RSS XML
  if (typeof data === 'string' && data.includes('<item>')) {
    const itemMatches = data.match(/<item>([\s\S]*?)<\/item>/g) || [];

    return itemMatches.map((itemXml) => ({
      source_id: extractXmlTag(itemXml, 'guid') || extractXmlTag(itemXml, 'link'),
      title: extractXmlTag(itemXml, 'title'),
      description: extractXmlTag(itemXml, 'description'),
      url: extractXmlTag(itemXml, 'link'),
      updated_at: extractXmlTag(itemXml, 'pubDate') || new Date().toISOString(),
      image: extractXmlTag(itemXml, 'image') || null,
      entity_type: 'article',
      change_type: 'new',
      taxonomies: {},
      source_type: 'rss',
    }));
  }

  logger.warn(
    `⚠️ DrFyto Main parser vrátil neočakávanú štruktúru. Dostali: ${safePreview(data)}`
  );

  return [];
}

/**
 * Parser pre TopTour.
 * Podporuje:
 * 1. Nový JSON formát s data.items
 * 2. Starší JSON formát s data.events
 * 3. RSS XML
 */
export function parseTopTourData(data) {
  // 1. Nový JSON endpoint / items
  if (data && Array.isArray(data.items)) {
    return data.items.map((item) => ({
      source_id: item.source_id,
      title: item.title,
      description: item.description || '',
      url: item.url,
      updated_at: item.updated_at || new Date().toISOString(),
      image: item.image || null,
      entity_type: item.entity_type || 'event',
      change_type: item.change_type || 'new',
      taxonomies: item.taxonomies || {},
      source_type: item.source_type || 'event',
    }));
  }

  // 2. Starší JSON formát / events
  if (data && Array.isArray(data.events)) {
    return data.events.map((event) => ({
      source_id: event.id || event.source_id,
      title: event.title || event.name,
      description: event.description || event.excerpt || '',
      url: event.url || event.link,
      updated_at: event.updated_at || event.date || new Date().toISOString(),
      image: event.image || null,
      entity_type: event.entity_type || 'event',
      change_type: event.change_type || 'new',
      taxonomies: event.taxonomies || {},
      source_type: event.source_type || 'event',
    }));
  }

  // 3. RSS XML
  if (typeof data === 'string' && data.includes('<item>')) {
    const itemMatches = data.match(/<item>([\s\S]*?)<\/item>/g) || [];

    return itemMatches.map((itemXml) => ({
      source_id: extractXmlTag(itemXml, 'guid') || extractXmlTag(itemXml, 'link'),
      title: extractXmlTag(itemXml, 'title'),
      description: extractXmlTag(itemXml, 'description'),
      url: extractXmlTag(itemXml, 'link'),
      updated_at: extractXmlTag(itemXml, 'pubDate') || new Date().toISOString(),
      image: extractXmlTag(itemXml, 'image') || null,
      entity_type: 'event',
      change_type: 'new',
      taxonomies: {},
      source_type: 'rss',
    }));
  }

  logger.warn(
    `⚠️ TopTour parser vrátil neočakávanú štruktúru. Dostali: ${safePreview(data)}`
  );

  return [];
}

/**
 * Univerzálny dispatcher podľa zdroja.
 */
export function parseSource(source, data) {
  switch (source) {
    case 'shop':
      return parseShopData(data);
    case 'kb':
      return parseKBData(data);
    case 'drfyto':
      return parseDrfytoData(data);
    case 'toptour':
      return parseTopTourData(data);
    default:
      logger.warn(`⚠️ Neznámy zdroj pre parser: ${source}`);
      return [];
  }
}