import crypto from 'crypto';
import pb from './pocketbaseClient.js';
import logger from './logger.js';

/**
 * Check if an update is a duplicate
 * Returns {isDuplicate: boolean, existingId: string|null, reason: string}
 */
export async function isDuplicate(source, sourceId, canonicalUrl, hash, lastProcessedFingerprints = []) {
  try {
    // Check 1: source + source_id (primary)
    if (sourceId) {
      const existingById = await pb.collection('updates').getFirstListItem(
        `source = "${source}" && source_id = "${sourceId}"`,
        { requestKey: null }
      ).catch(() => null);

      if (existingById) {
        return {
          isDuplicate: true,
          existingId: existingById.id,
          reason: 'Duplicate by source + source_id',
        };
      }
    }

    // Check 2: source + canonical_url (secondary)
    if (canonicalUrl) {
      const existingByUrl = await pb.collection('updates').getFirstListItem(
        `source = "${source}" && canonical_url = "${canonicalUrl}"`,
        { requestKey: null }
      ).catch(() => null);

      if (existingByUrl) {
        return {
          isDuplicate: true,
          existingId: existingByUrl.id,
          reason: 'Duplicate by source + canonical_url',
        };
      }
    }

    // Check 3: source + hash (tertiary)
    if (hash) {
      const existingByHash = await pb.collection('updates').getFirstListItem(
        `source = "${source}" && hash = "${hash}"`,
        { requestKey: null }
      ).catch(() => null);

      if (existingByHash) {
        return {
          isDuplicate: true,
          existingId: existingByHash.id,
          reason: 'Duplicate by source + hash',
        };
      }
    }

    // Check 4: Against last_processed_fingerprints (max 10 hashes)
    if (hash && lastProcessedFingerprints.includes(hash)) {
      return {
        isDuplicate: true,
        existingId: null,
        reason: 'Duplicate in last_processed_fingerprints',
      };
    }

    return {
      isDuplicate: false,
      existingId: null,
      reason: 'Not a duplicate',
    };
  } catch (error) {
    logger.error(`Error checking for duplicates: ${error.message}`);
    throw error;
  }
}

/**
 * Generate hash from content
 */
export function generateHash(content) {
  return crypto.createHash('sha256').update(content).digest('hex');
}