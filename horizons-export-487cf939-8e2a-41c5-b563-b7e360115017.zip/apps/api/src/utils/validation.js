import logger from './logger.js';

/**
 * Validate update data
 * Returns {isValid: boolean, errors: array, excerpt: string, significance_level: string}
 */
export function validateUpdate(data) {
  const errors = [];
  let excerpt = data.excerpt || '';
  let significance_level = 'medium';

  // Validate title
  if (!data.title) {
    errors.push('Title is required');
  } else {
    const cleanTitle = stripHtmlTags(data.title);
    if (cleanTitle.length < 10) {
      errors.push('Title must be at least 10 characters long');
    }
    data.title = cleanTitle;
  }

  // Validate source_url
  if (!data.source_url) {
    errors.push('Source URL is required');
  } else {
    if (!isValidUrl(data.source_url)) {
      errors.push('Source URL must be a valid URL');
    }
    if (isInternalPath(data.source_url)) {
      errors.push('Source URL cannot be an internal path');
    }
  }

  // Validate source_id (optional but must be string if present)
  if (data.source_id && typeof data.source_id !== 'string') {
    errors.push('Source ID must be a string');
  }

  // Normalize canonical_url
  if (data.source_url) {
    data.canonical_url = normalizeUrl(data.source_url);
  }

  // Generate excerpt if missing
  if (!excerpt) {
    excerpt = generateExcerpt(data);
  }

  // Determine significance level
  if (data.change_type === 'new' || data.entity_type === 'product' || data.entity_type === 'event') {
    significance_level = 'high';
  } else if (data.change_type === 'updated') {
    significance_level = 'medium';
  } else {
    significance_level = 'low';
  }

  if (errors.length > 0) {
    logger.warn(`Validation errors for update: ${errors.join(', ')}`);
  }

  return {
    isValid: errors.length === 0,
    errors,
    excerpt,
    significance_level,
  };
}

/**
 * Strip HTML tags from string
 */
function stripHtmlTags(str) {
  return str.replace(/<[^>]*>/g, '').trim();
}

/**
 * Check if string is a valid URL
 */
function isValidUrl(str) {
  try {
    new URL(str);
    return true;
  } catch {
    return false;
  }
}

/**
 * Check if URL is an internal path
 */
function isInternalPath(url) {
  const internalPaths = ['/admin', '/api', '/tag/', '/search'];
  return internalPaths.some((path) => url.includes(path));
}

/**
 * Normalize URL: remove query params, fragments, trailing slashes
 */
function normalizeUrl(url) {
  try {
    const urlObj = new URL(url);
    urlObj.search = '';
    urlObj.hash = '';
    let normalized = urlObj.toString();
    if (normalized.endsWith('/')) {
      normalized = normalized.slice(0, -1);
    }
    return normalized;
  } catch {
    return url;
  }
}

/**
 * Generate excerpt based on entity_type and change_type
 */
function generateExcerpt(data) {
  const { entity_type, change_type, title, description } = data;

  if (description) {
    return description.substring(0, 200);
  }

  if (change_type === 'new') {
    return `New ${entity_type}: ${title}`;
  }

  if (change_type === 'updated') {
    return `Updated ${entity_type}: ${title}`;
  }

  return title;
}