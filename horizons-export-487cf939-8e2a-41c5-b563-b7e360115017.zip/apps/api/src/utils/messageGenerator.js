import logger from './logger.js';

const TEMPLATES = {
  NEW_PRODUCT: 'Na Jarmok.shop pribudol nový produkt: {name}',
  UPDATED_PRODUCT_PRICE: 'Zmena ceny na Jarmok.shop: {name}',
  UPDATED_PRODUCT_AVAILABILITY: '{name} je opäť dostupný na Jarmok.shop',
  NEW_ARTICLE: 'V znalostnej báze pribudol nový článok: {title}',
  UPDATED_ARTICLE: 'Bol aktualizovaný článok: {title}',
  NEW_EVENT: 'TopTour zverejnil nové podujatie: {name}',
  UPDATED_EVENT: 'Zmena v podujatí: {name}',
};

/**
 * Generate update message based on source, entity type, and change type
 * Returns {title: string, excerpt: string}
 */
export function generateUpdate(source, entityType, changeType, data) {
  try {
    let templateKey = '';
    let templateData = {};

    // Determine template key
    if (source === 'shop') {
      if (entityType === 'product' && changeType === 'new') {
        templateKey = 'NEW_PRODUCT';
        templateData = { name: data.title || data.name || 'Produkt' };
      } else if (entityType === 'product' && changeType === 'price_change') {
        templateKey = 'UPDATED_PRODUCT_PRICE';
        templateData = { name: data.title || data.name || 'Produkt' };
      } else if (entityType === 'product' && changeType === 'availability_change') {
        templateKey = 'UPDATED_PRODUCT_AVAILABILITY';
        templateData = { name: data.title || data.name || 'Produkt' };
      }
    } else if (source === 'kb' || source === 'drfyto') {
      if (entityType === 'article' && changeType === 'new') {
        templateKey = 'NEW_ARTICLE';
        templateData = { title: data.title || 'Článok' };
      } else if (entityType === 'article' && changeType === 'updated') {
        templateKey = 'UPDATED_ARTICLE';
        templateData = { title: data.title || 'Článok' };
      }
    } else if (source === 'toptour') {
      if (entityType === 'event' && changeType === 'new') {
        templateKey = 'NEW_EVENT';
        templateData = { name: data.title || data.name || 'Podujatie' };
      } else if (entityType === 'event' && changeType === 'updated') {
        templateKey = 'UPDATED_EVENT';
        templateData = { name: data.title || data.name || 'Podujatie' };
      }
    }

    // Get template or use fallback
    let template = TEMPLATES[templateKey];
    if (!template) {
      template = `${changeType === 'new' ? 'New' : 'Updated'} ${entityType}: {title}`;
      templateData = { title: data.title || 'Item' };
    }

    // Replace placeholders
    const title = replacePlaceholders(template, templateData);
    const excerpt = data.description || title;

    return {
      title,
      excerpt,
    };
  } catch (error) {
    logger.error(`Error generating message: ${error.message}`);
    return {
      title: data.title || 'Update',
      excerpt: data.description || data.title || 'Update',
    };
  }
}

/**
 * Replace placeholders in template string
 */
function replacePlaceholders(template, data) {
  let result = template;
  Object.entries(data).forEach(([key, value]) => {
    result = result.replace(new RegExp(`{${key}}`, 'g'), value || '');
  });
  return result;
}