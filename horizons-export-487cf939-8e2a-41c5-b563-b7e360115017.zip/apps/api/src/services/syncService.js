import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';
import { fetchShop, fetchKB, fetchDrfyto, fetchTopTour } from '../connectors/sourceConnectors.js';
import { parseShopData, parseKBData, parseDrfytoData, parseTopTourData } from '../parsers/sourceParsers.js';
import { isDuplicate, generateHash } from '../utils/deduplication.js';
import { validateUpdate } from '../utils/validation.js';
import { generateUpdate } from '../utils/messageGenerator.js';

const SOURCE_CONFIG = {
  shop: {
    fetchFn: fetchShop,
    parseFn: parseShopData,
    entityType: 'product',
  },
  kb: {
    fetchFn: fetchKB,
    parseFn: parseKBData,
    entityType: 'article',
  },
  drfyto: {
    fetchFn: fetchDrfyto,
    parseFn: parseDrfytoData,
    entityType: 'article',
  },
  toptour: {
    fetchFn: fetchTopTour,
    parseFn: parseTopTourData,
    entityType: 'event',
  },
};

/**
 * Main synchronization orchestration
 * Executes 8-step workflow for a source
 */
export async function syncSource(source) {
  const config = SOURCE_CONFIG[source];
  if (!config) {
    throw new Error(`Unknown source: ${source}`);
  }

  const results = {
    success: false,
    itemsCreated: 0,
    itemsUpdated: 0,
    itemsSkipped: 0,
    errors: [],
  };

  try {
    logger.info(`Starting sync for source: ${source}`);

    // Step 1: FETCH
    logger.info(`[${source}] Step 1: FETCH`);
    let rawData;
    try {
      rawData = await config.fetchFn();
    } catch (error) {
      logger.error(`[${source}] Fetch failed: ${error.message}`);
      results.errors.push(`Fetch error: ${error.message}`);
      throw error;
    }

    // Step 2: PARSE
    logger.info(`[${source}] Step 2: PARSE`);
    const items = config.parseFn(rawData);
    logger.info(`[${source}] Parsed ${items.length} items`);

    // Step 3: COMPARE with last_processed_timestamp
    logger.info(`[${source}] Step 3: COMPARE`);
    let syncState;
    try {
      syncState = await pb.collection('sync_state').getFirstListItem(`source = "${source}"`, {
        requestKey: null,
      });
    } catch {
      syncState = null;
    }

    const lastProcessedTimestamp = syncState?.last_processed_timestamp
      ? new Date(syncState.last_processed_timestamp)
      : new Date(0);

    const newItems = items.filter((item) => {
      const itemDate = new Date(item.updated_at || new Date());
      return itemDate > lastProcessedTimestamp;
    });

    logger.info(`[${source}] Filtered to ${newItems.length} new items`);

    // Step 4: DEDUPLICATE
    logger.info(`[${source}] Step 4: DEDUPLICATE`);
    const lastProcessedFingerprints = syncState?.last_processed_fingerprints || [];
    const deduplicatedItems = [];
    let skippedCount = 0;

    for (const item of newItems) {
      const hash = generateHash(JSON.stringify(item));
      const dupCheck = await isDuplicate(source, item.source_id, item.url, hash, lastProcessedFingerprints);

      if (dupCheck.isDuplicate) {
        logger.info(`[${source}] Skipped duplicate: ${dupCheck.reason}`);
        skippedCount++;
      } else {
        deduplicatedItems.push({ ...item, hash });
      }
    }

    results.itemsSkipped = skippedCount;
    logger.info(`[${source}] Deduplicated: ${deduplicatedItems.length} items, skipped ${skippedCount}`);

    // Step 5: VALIDATE
    logger.info(`[${source}] Step 5: VALIDATE`);
    const validatedItems = [];

    for (const item of deduplicatedItems) {
      const validationResult = validateUpdate({
        title: item.title,
        source_url: item.url,
        source_id: item.source_id,
        description: item.description,
        excerpt: item.description,
        entity_type: config.entityType,
        change_type: 'new',
      });

      validatedItems.push({
        ...item,
        ...validationResult,
      });

      if (!validationResult.isValid) {
        logger.warn(`[${source}] Validation errors for ${item.title}: ${validationResult.errors.join(', ')}`);
      }
    }

    // Step 6: EVALUATE_SIGNIFICANCE
    logger.info(`[${source}] Step 6: EVALUATE_SIGNIFICANCE`);
    const significantItems = validatedItems.filter((item) => {
      if (item.significance_level === 'low') {
        logger.info(`[${source}] Skipped low-significance item: ${item.title}`);
        results.itemsSkipped++;
        return false;
      }
      return true;
    });

    // Step 7: GENERATE_MESSAGE
    logger.info(`[${source}] Step 7: GENERATE_MESSAGE`);
    const messagesItems = significantItems.map((item) => {
      const message = generateUpdate(source, config.entityType, 'new', item);
      return {
        ...item,
        ...message,
      };
    });

    // Step 8: SAVE_TO_DB
    logger.info(`[${source}] Step 8: SAVE_TO_DB`);
    const now = new Date().toISOString();
    const newFingerprints = messagesItems.map((item) => item.hash).slice(0, 10);

    for (const item of messagesItems) {
      try {
        const recordData = {
          source,
          source_id: item.source_id,
          title: item.title,
          excerpt: item.excerpt,
          description: item.description,
          source_url: item.url,
          canonical_url: item.url,
          image: item.image || '',
          status: item.isValid ? 'published' : 'draft',
          published_at: item.isValid ? now : null,
          detected_at: now,
          raw_payload: JSON.stringify(item),
          metadata: JSON.stringify({
            entity_type: config.entityType,
            significance_level: item.significance_level,
            validation_errors: item.errors,
          }),
          hash: item.hash,
        };

        await pb.collection('updates').create(recordData, { requestKey: null });
        results.itemsCreated++;
        logger.info(`[${source}] Created update: ${item.title}`);
      } catch (error) {
        logger.error(`[${source}] Failed to save update: ${error.message}`);
        results.errors.push(`Save error: ${error.message}`);
      }
    }

    // Step 9: UPDATE_SYNC_STATE
    logger.info(`[${source}] Step 9: UPDATE_SYNC_STATE`);
    try {
      if (syncState) {
        await pb.collection('sync_state').update(
          syncState.id,
          {
            last_successful_check: now,
            last_processed_timestamp: now,
            last_processed_fingerprints: newFingerprints,
            items_new: results.itemsCreated,
            items_updated: results.itemsUpdated,
            items_skipped: results.itemsSkipped,
            fetch_status: 'success',
            error_message: null,
          },
          { requestKey: null }
        );
      }
    } catch (error) {
      logger.error(`[${source}] Failed to update sync_state: ${error.message}`);
      results.errors.push(`Sync state update error: ${error.message}`);
    }

    // Log to sync_logs
    try {
      await pb.collection('sync_logs').create(
        {
          source,
          status: 'success',
          items_created: results.itemsCreated,
          items_updated: results.itemsUpdated,
          items_skipped: results.itemsSkipped,
          errors: results.errors.join('; '),
          timestamp: now,
        },
        { requestKey: null }
      );
    } catch (error) {
      logger.error(`[${source}] Failed to log sync: ${error.message}`);
    }

    results.success = true;
    logger.info(`[${source}] Sync completed successfully`);
    return results;
  } catch (error) {
    logger.error(`[${source}] Sync failed: ${error.message}`);
    results.success = false;
    results.errors.push(error.message);

    // Log failure to sync_logs
    try {
      const now = new Date().toISOString();
      await pb.collection('sync_logs').create(
        {
          source,
          status: 'failed',
          items_created: results.itemsCreated,
          items_updated: results.itemsUpdated,
          items_skipped: results.itemsSkipped,
          errors: error.message,
          timestamp: now,
        },
        { requestKey: null }
      );
    } catch (logError) {
      logger.error(`Failed to log sync failure: ${logError.message}`);
    }

    throw error;
  }
}