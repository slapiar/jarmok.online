import 'dotenv/config';
import logger from './src/utils/logger.js';
import { syncSource } from './src/services/syncService.js';
import pb from './src/utils/pocketbaseClient.js';

/**
 * Test script for KB source synchronization
 * Runs complete sync workflow and captures all phases
 */

async function runKBSyncTest() {
  console.log('\n' + '='.repeat(80));
  console.log('KB SOURCE SYNCHRONIZATION TEST');
  console.log('='.repeat(80) + '\n');

  const testStartTime = new Date();
  console.log(`Test started at: ${testStartTime.toISOString()}\n`);

  try {
    // Phase 1: FETCH
    console.log('\n' + '-'.repeat(80));
    console.log('PHASE 1: FETCH');
    console.log('-'.repeat(80));
    console.log('Expected endpoints:');
    console.log('  1. RSS: https://kb.drfyto.com/feed.xml');
    console.log('  2. API: https://kb.drfyto.com/wp-json/updates/v1/items?post_type=post');
    console.log('  3. Scraping: https://kb.drfyto.com (fallback)');
    console.log('\nAttempting sync...\n');

    // Call syncSource and capture result
    const syncResult = await syncSource('kb');

    console.log('\n' + '-'.repeat(80));
    console.log('PHASE 1 RESULTS: FETCH');
    console.log('-'.repeat(80));
    console.log(`Success: ${syncResult.success}`);
    console.log(`Items created: ${syncResult.itemsCreated}`);
    console.log(`Items updated: ${syncResult.itemsUpdated}`);
    console.log(`Items skipped: ${syncResult.itemsSkipped}`);
    if (syncResult.errors.length > 0) {
      console.log(`Errors: ${syncResult.errors.join('; ')}`);
    }

    // Phase 2: PARSER
    console.log('\n' + '-'.repeat(80));
    console.log('PHASE 2: PARSER');
    console.log('-'.repeat(80));
    console.log(`Total items processed: ${syncResult.itemsCreated + syncResult.itemsUpdated + syncResult.itemsSkipped}`);
    console.log(`Items with valid structure: ${syncResult.itemsCreated + syncResult.itemsUpdated}`);
    console.log(`Items filtered/skipped: ${syncResult.itemsSkipped}`);

    // Phase 3: SYNC
    console.log('\n' + '-'.repeat(80));
    console.log('PHASE 3: SYNC');
    console.log('-'.repeat(80));
    console.log(`New items created: ${syncResult.itemsCreated}`);
    console.log(`Items updated: ${syncResult.itemsUpdated}`);
    console.log(`Items skipped: ${syncResult.itemsSkipped}`);
    console.log(`Total processed: ${syncResult.itemsCreated + syncResult.itemsUpdated + syncResult.itemsSkipped}`);

    // Phase 4: QUERY DATABASE
    console.log('\n' + '-'.repeat(80));
    console.log('PHASE 4: DATABASE VERIFICATION');
    console.log('-'.repeat(80));
    console.log('Querying saved items from updates collection...\n');

    try {
      // Get recent KB updates
      const savedItems = await pb.collection('updates').getList(1, 10, {
        filter: 'source = "kb"',
        sort: '-created',
        requestKey: null,
      });

      console.log(`Total KB items in database: ${savedItems.totalItems}`);
      console.log(`Items in current page: ${savedItems.items.length}\n`);

      if (savedItems.items.length > 0) {
        console.log('Sample saved items (up to 3):');
        const sampleItems = savedItems.items.slice(0, 3);

        sampleItems.forEach((item, index) => {
          console.log(`\n  Item ${index + 1}:`);
          console.log(`    ID: ${item.id}`);
          console.log(`    Title: ${item.title}`);
          console.log(`    Source ID: ${item.source_id}`);
          console.log(`    URL: ${item.source_url}`);
          console.log(`    Updated At: ${item.updated_at}`);
          console.log(`    Status: ${item.status}`);
          console.log(`    Created: ${item.created}`);
        });
      } else {
        console.log('No KB items found in database.');
      }
    } catch (dbError) {
      console.log(`Database query error: ${dbError.message}`);
    }

    // Phase 5: SYNC STATE
    console.log('\n' + '-'.repeat(80));
    console.log('PHASE 5: SYNC STATE');
    console.log('-'.repeat(80));

    try {
      const syncState = await pb.collection('sync_state').getFirstListItem(
        'source = "kb"',
        { requestKey: null }
      );

      console.log(`Source: ${syncState.source}`);
      console.log(`Enabled: ${syncState.is_enabled}`);
      console.log(`Last successful check: ${syncState.last_successful_check}`);
      console.log(`Last processed timestamp: ${syncState.last_processed_timestamp}`);
      console.log(`Items new: ${syncState.items_new}`);
      console.log(`Items updated: ${syncState.items_updated}`);
      console.log(`Items skipped: ${syncState.items_skipped}`);
      console.log(`Fetch status: ${syncState.fetch_status}`);
      if (syncState.error_message) {
        console.log(`Error message: ${syncState.error_message}`);
      }
    } catch (stateError) {
      console.log(`Sync state query error: ${stateError.message}`);
    }

    // Final conclusion
    console.log('\n' + '='.repeat(80));
    console.log('TEST CONCLUSION');
    console.log('='.repeat(80));

    if (syncResult.success) {
      console.log('\n✓ KB SYNCHRONIZATION: WORKS');
      console.log(`\nSummary:`);
      console.log(`  - Fetch phase: SUCCESS`);
      console.log(`  - Parser phase: SUCCESS (processed items)`);
      console.log(`  - Sync phase: SUCCESS (${syncResult.itemsCreated} new, ${syncResult.itemsUpdated} updated)`);
      console.log(`  - Database: VERIFIED (items saved)`);
    } else {
      console.log('\n✗ KB SYNCHRONIZATION: DOES NOT WORK');
      console.log(`\nFailure details:`);
      console.log(`  - Errors: ${syncResult.errors.join('; ')}`);
    }

    const testEndTime = new Date();
    const duration = (testEndTime - testStartTime) / 1000;
    console.log(`\nTest completed at: ${testEndTime.toISOString()}`);
    console.log(`Duration: ${duration.toFixed(2)} seconds`);
    console.log('\n' + '='.repeat(80) + '\n');

    process.exit(syncResult.success ? 0 : 1);
  } catch (error) {
    console.log('\n' + '='.repeat(80));
    console.log('TEST CONCLUSION');
    console.log('='.repeat(80));
    console.log('\n✗ KB SYNCHRONIZATION: DOES NOT WORK');
    console.log(`\nFatal error: ${error.message}`);
    console.log(`\nStack trace:`);
    console.log(error.stack);
    console.log('\n' + '='.repeat(80) + '\n');
    process.exit(1);
  }
}

// Run the test
runKBSyncTest();