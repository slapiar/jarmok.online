# Changelog

## [0.1.1] - 2026-04-12

### Type
PATCH

### Summary
Refactored hardcoded API endpoints into centralized configuration system. Introduced enabled/disabled source management and improved logging with emoji indicators for better operational visibility.

### Modified Files
- `apps/api/src/connectors/sourceConnectors.js` - Refactored to use SOURCES_CONFIG, added enabled flag checks, improved logging
- `apps/api/src/parsers/sourceParsers.js` - Added defensive parsing with fallback logic and diagnostic logging
- `apps/api/src/schedulers/updatesSyncScheduler.js` - Integrated source configuration checks, enhanced logging

### New Files
- `apps/api/src/config/sources.config.js` - Centralized configuration for all 4 sources (shop, kb, drfyto, toptour)
- `apps/api/CHANGELOG.md` - This changelog file

### Changes

#### Configuration Management
- Created `SOURCES_CONFIG` object with configuration for all 4 sources
- Each source now has: name, enabled flag, sourceType, and endpoint configurations
- All endpoints include: url, timeout (30s), and status field (placeholder/confirmed)
- Exported helper functions: `getSourceConfig()`, `isSourceEnabled()`, `isEndpointPlaceholder()`, `getEndpointConfig()`

#### Source Connectors
- Removed hardcoded `API_ENDPOINTS` and `RSS_FEEDS` constants
- Refactored `fetchShop()`, `fetchKB()`, `fetchDrfyto()`, `fetchTopTour()` to use configuration
- Added enabled flag checks - disabled sources log and return null
- Added placeholder endpoint detection with warning logs
- Implemented fallback chain: API → RSS → Scraping with detailed logging at each step
- All logging in Slovak with emoji prefixes (✓, ✗, ⚠️, ℹ️, 🔄)

#### Source Parsers
- Added defensive parsing with structure validation
- Implemented fallback logic for alternative data structures
- Added diagnostic logging for unexpected data formats
- All parsers now handle: primary structure → fallback structures → error handling
- Improved error messages with data preview for debugging

#### Scheduler
- Integrated source configuration checks into sync workflow
- Added enabled flag validation before syncing
- Added placeholder endpoint warnings
- Enhanced logging with emoji indicators and Slovak messages
- Improved error handling and result reporting

### Risk Assessment
**LOW RISK** - Changes are localized to configuration and logging layers:
- No changes to core sync workflow or data model
- No changes to database schema or API contracts
- All endpoints remain at same URLs (only moved to config)
- Backward compatible - existing functionality preserved
- Fallback logic ensures robustness

### Next Steps
1. **Real API Integration**: Replace placeholder endpoints with confirmed URLs from:
   - Jarmok Shop: Confirm API endpoint and RSS feed URLs
   - DrFyto KB: Confirm RSS feed and API endpoint URLs
   - DrFyto Main: Confirm RSS feed and API endpoint URLs
   - TopTour: Confirm API endpoint and scraping strategy

2. **Endpoint Validation**: Once real URLs are confirmed:
   - Update `status` field from 'placeholder' to 'confirmed' in SOURCES_CONFIG
   - Test each endpoint with real data
   - Update parsers if data structure differs from expectations

3. **Scraping Implementation**: Implement scraping fallback for sources without API/RSS:
   - TopTour scraping (currently logs TODO)
   - Shop scraping (currently logs TODO)
   - Use cheerio for HTML parsing if needed

4. **Monitoring**: Set up alerts for:
   - Placeholder endpoint usage (indicates missing real API)
   - Disabled sources (track why they're disabled)
   - Fallback chain activation (indicates primary endpoint failure)