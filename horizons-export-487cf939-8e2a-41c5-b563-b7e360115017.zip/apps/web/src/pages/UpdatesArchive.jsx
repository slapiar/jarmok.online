import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Activity } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import UpdatesList from '@/components/UpdatesList.jsx';
import UpdatesFilter from '@/components/UpdatesFilter.jsx';
import { Button } from '@/components/ui/button';

const UpdatesArchive = () => {
  const [updates, setUpdates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [filter, setFilter] = useState('all');
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  const fetchUpdates = async (pageNum, currentFilter, append = false) => {
    try {
      setLoading(true);
      
      let filterString = 'status="published"';
      
      if (currentFilter === 'high_significance') {
        filterString += ' && significance_level="high"';
      } else if (currentFilter.startsWith('source_')) {
        const source = currentFilter.replace('source_', '');
        filterString += ` && source="${source}"`;
      } else if (currentFilter === 'type_new') {
        filterString += ' && change_type="new"';
      } else if (currentFilter === 'type_updated') {
        filterString += ' && change_type="updated"';
      }

      const records = await pb.collection('updates').getList(pageNum, 20, {
        sort: '-published_at,-created',
        filter: filterString,
        $autoCancel: false
      });

      if (append) {
        setUpdates(prev => [...prev, ...records.items]);
      } else {
        setUpdates(records.items);
      }
      
      setHasMore(records.page < records.totalPages);
      setError(false);
    } catch (err) {
      console.error('Error fetching updates archive:', err);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setPage(1);
    fetchUpdates(1, filter, false);
  }, [filter]);

  const handleLoadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchUpdates(nextPage, filter, true);
  };

  return (
    <>
      <Helmet>
        <title>Aktuality ekosystému | jarmok.online</title>
        <meta name="description" content="Prehľad všetkých noviniek, aktualizácií a zmien v ekosystéme jarmok.online, Dr. Fyto a TopTour." />
      </Helmet>

      <Header />

      <main className="min-h-screen pb-20">
        <section className="bg-gradient-to-b from-accent to-background py-16 mb-8">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-2xl mb-6">
              <Activity className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold mb-4 leading-tight" style={{ letterSpacing: '-0.02em' }}>
              Aktuality ekosystému
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              Sledujte najnovšie produkty, články a podujatia naprieč celým naším ekosystémom na jednom mieste.
            </p>
          </div>
        </section>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <UpdatesFilter currentFilter={filter} onFilterChange={setFilter} />
          
          <div className="mt-8">
            <UpdatesList updates={updates} loading={loading && page === 1} error={error} />
            
            {hasMore && !loading && !error && updates.length > 0 && (
              <div className="mt-10 text-center">
                <Button variant="outline" onClick={handleLoadMore} className="rounded-full px-8">
                  Načítať staršie aktuality
                </Button>
              </div>
            )}
            
            {loading && page > 1 && (
              <div className="mt-8 text-center text-sm text-muted-foreground">
                Načítavam ďalšie...
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </>
  );
};

export default UpdatesArchive;