import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Newspaper } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ArticleCard from '@/components/ArticleCard.jsx';
import CampaignBlock from '@/components/CampaignBlock.jsx';
import UpdatesSection from '@/components/UpdatesSection.jsx';
import { Skeleton } from '@/components/ui/skeleton';

const HomePage = () => {
  const [campaigns, setCampaigns] = useState([]);
  const [featuredArticle, setFeaturedArticle] = useState(null);
  const [articlesByCampaign, setArticlesByCampaign] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const campaignsData = await pb.collection('campaigns').getFullList({
          sort: 'created',
          $autoCancel: false
        });
        setCampaigns(campaignsData);

        const allArticles = await pb.collection('articles').getFullList({
          sort: '-created',
          expand: 'campaign_id',
          $autoCancel: false
        });

        if (allArticles.length > 0) {
          setFeaturedArticle(allArticles[0]);
        }

        const grouped = {};
        campaignsData.forEach(campaign => {
          grouped[campaign.id] = allArticles.filter(
            article => article.campaign_id === campaign.id
          );
        });
        setArticlesByCampaign(grouped);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <>
        <Header />
        <main className="min-h-screen">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <Skeleton className="h-96 w-full rounded-2xl mb-12" />
            <Skeleton className="h-64 w-full rounded-xl" />
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Digitálne noviny ekosystému | jarmok.online</title>
        <meta
          name="description"
          content="Objavte príbehy o udržateľnom živote, prírodných produktoch a harmónii s prírodou. Digitálne noviny ekosystému jarmok.online."
        />
      </Helmet>

      <Header />

      <main className="min-h-screen">
        <section className="bg-gradient-to-b from-accent to-background py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-primary/10 rounded-2xl mb-6">
                <Newspaper className="h-10 w-10 text-primary" />
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6 leading-tight" style={{ letterSpacing: '-0.02em' }}>
                Digitálne noviny ekosystému
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
                Objavte príbehy o udržateľnom živote, prírodných produktoch a harmónii s prírodou. 
                Každý článok je krokom k lepšiemu zajtrajšku.
              </p>
            </div>
          </div>
        </section>

        {featuredArticle && (
          <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <h2 className="text-2xl font-display font-bold mb-8">Hlavný článok</h2>
            <ArticleCard
              article={featuredArticle}
              campaign={featuredArticle.expand?.campaign_id}
              variant="featured"
            />
          </section>
        )}

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="space-y-16">
            {campaigns.map((campaign) => {
              const articles = articlesByCampaign[campaign.id] || [];
              if (articles.length === 0) return null;

              return (
                <CampaignBlock
                  key={campaign.id}
                  campaign={campaign}
                  articles={articles}
                />
              );
            })}
          </div>

          {campaigns.every(c => (articlesByCampaign[c.id] || []).length === 0) && (
            <div className="text-center py-20">
              <Newspaper className="h-16 w-16 text-muted-foreground/50 mx-auto mb-4" />
              <h3 className="text-xl font-display font-semibold mb-2">Zatiaľ žiadne články</h3>
              <p className="text-muted-foreground">Nové príbehy už čoskoro.</p>
            </div>
          )}
        </div>

        <UpdatesSection />
      </main>

      <Footer />
    </>
  );
};

export default HomePage;