import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Calendar, ArrowLeft } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import CTABlock from '@/components/CTABlock.jsx';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';

const ArticleDetailPage = () => {
  const { articleSlug } = useParams();
  const [article, setArticle] = useState(null);
  const [ctaBlocks, setCtaBlocks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const articleData = await pb.collection('articles').getFirstListItem(
          `slug="${articleSlug}"`,
          {
            expand: 'campaign_id,cta_blocks',
            $autoCancel: false
          }
        );
        setArticle(articleData);

        if (articleData.expand?.cta_blocks) {
          setCtaBlocks(Array.isArray(articleData.expand.cta_blocks) 
            ? articleData.expand.cta_blocks 
            : [articleData.expand.cta_blocks]
          );
        }
      } catch (error) {
        console.error('Error fetching article:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [articleSlug]);

  if (loading) {
    return (
      <>
        <Header />
        <main className="min-h-screen">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <Skeleton className="h-12 w-3/4 mb-4" />
            <Skeleton className="h-96 w-full rounded-2xl mb-8" />
            <Skeleton className="h-64 w-full" />
          </div>
        </main>
        <Footer />
      </>
    );
  }

  if (!article) {
    return (
      <>
        <Header />
        <main className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-3xl font-display font-bold mb-4">Článok nenájdený</h1>
            <p className="text-muted-foreground mb-6">Tento článok neexistuje.</p>
            <Link to="/">
              <Button>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Späť na domov
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  const campaign = article.expand?.campaign_id;
  const imageUrl = article.featured_image
    ? pb.files.getUrl(article, article.featured_image)
    : null;

  return (
    <>
      <Helmet>
        <title>{`${article.title} | jarmok.online`}</title>
        <meta name="description" content={article.excerpt} />
      </Helmet>

      <Header />

      <main className="min-h-screen">
        <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Link
            to={campaign ? `/kampane/${campaign.slug}` : '/'}
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors duration-200 mb-8"
          >
            <ArrowLeft className="h-4 w-4" />
            Späť na {campaign ? campaign.name : 'domov'}
          </Link>

          {campaign && (
            <span
              className="inline-block px-3 py-1 text-sm font-semibold rounded-full mb-4"
              style={{
                backgroundColor: `${campaign.color}20`,
                color: campaign.color
              }}
            >
              {campaign.icon} {campaign.name}
            </span>
          )}

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6 leading-tight" style={{ letterSpacing: '-0.02em' }}>
            {article.title}
          </h1>

          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-8">
            <span className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              {new Date(article.created).toLocaleDateString('sk-SK', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </span>
          </div>

          {imageUrl && (
            <div className="relative h-96 rounded-2xl overflow-hidden mb-12">
              <img
                src={imageUrl}
                alt={article.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          <div className="prose prose-lg max-w-none">
            <p className="text-xl leading-relaxed text-muted-foreground mb-8">
              {article.excerpt}
            </p>

            <div
              className="leading-relaxed"
              style={{ whiteSpace: 'pre-wrap' }}
            >
              {article.content}
            </div>
          </div>

          {ctaBlocks.length > 0 && (
            <div className="mt-16 pt-16 border-t border-border">
              <h2 className="text-2xl font-display font-bold mb-8">Ďalšie kroky</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {ctaBlocks.map((cta) => (
                  <CTABlock key={cta.id} ctaBlock={cta} />
                ))}
              </div>
            </div>
          )}
        </article>
      </main>

      <Footer />
    </>
  );
};

export default ArticleDetailPage;