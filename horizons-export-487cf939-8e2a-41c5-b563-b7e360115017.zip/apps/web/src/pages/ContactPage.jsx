import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Mail, Send } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await pb.collection('contacts').create(formData, { $autoCancel: false });
      
      toast({
        title: "Správa odoslaná",
        description: "Ďakujeme za vašu správu. Čoskoro sa vám ozveme."
      });

      setFormData({ name: '', email: '', message: '' });
    } catch (error) {
      console.error('Error submitting contact form:', error);
      toast({
        title: "Chyba",
        description: "Nepodarilo sa odoslať správu. Skúste to prosím znova.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | jarmok.online</title>
        <meta
          name="description"
          content="Máte otázku alebo nápad? Napíšte nám. Radi sa s vami spojíme a pomôžeme vám."
        />
      </Helmet>

      <Header />

      <main className="min-h-screen">
        <section className="bg-gradient-to-b from-accent to-background py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl mx-auto text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-2xl mb-6">
                <Mail className="h-8 w-8 text-primary" />
              </div>
              <h1 className="text-4xl md:text-5xl font-display font-bold mb-6 leading-tight" style={{ letterSpacing: '-0.02em' }}>
                Kontaktujte nás
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Máte otázku, nápad alebo spätnú väzbu? Radi sa s vami spojíme.
              </p>
            </div>
          </div>
        </section>

        <section className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="bg-card rounded-2xl shadow-lg p-8 md:p-12">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="name">Meno</Label>
                <Input
                  id="name"
                  name="name"
                  type="text"
                  required
                  value={formData.name}
                  onChange={handleChange}
                  className="mt-2 text-foreground"
                  placeholder="Vaše meno"
                />
              </div>

              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className="mt-2 text-foreground"
                  placeholder="vas@email.sk"
                />
              </div>

              <div>
                <Label htmlFor="message">Správa</Label>
                <Textarea
                  id="message"
                  name="message"
                  required
                  value={formData.message}
                  onChange={handleChange}
                  rows={6}
                  className="mt-2 text-foreground"
                  placeholder="Napíšte nám vašu správu..."
                />
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full transition-all duration-200 active:scale-[0.98]"
              >
                {loading ? (
                  'Odeosielam...'
                ) : (
                  <>
                    Odoslať správu
                    <Send className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </form>
          </div>

          <div className="mt-12 text-center">
            <h2 className="text-2xl font-display font-bold mb-6">Naše platformy</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <a
                href="https://jarmok.shop"
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 bg-muted rounded-xl hover:bg-muted/80 transition-colors duration-200"
              >
                <h3 className="font-semibold mb-1">Jarmok Shop</h3>
                <p className="text-sm text-muted-foreground">Prírodné produkty</p>
              </a>
              <a
                href="https://kb.drfyto.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 bg-muted rounded-xl hover:bg-muted/80 transition-colors duration-200"
              >
                <h3 className="font-semibold mb-1">Knowledge Base</h3>
                <p className="text-sm text-muted-foreground">Vzdelávacie zdroje</p>
              </a>
              <a
                href="https://drfyto.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 bg-muted rounded-xl hover:bg-muted/80 transition-colors duration-200"
              >
                <h3 className="font-semibold mb-1">Dr. Fyto</h3>
                <p className="text-sm text-muted-foreground">Hlavná stránka</p>
              </a>
              <a
                href="https://toptour.sk"
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 bg-muted rounded-xl hover:bg-muted/80 transition-colors duration-200"
              >
                <h3 className="font-semibold mb-1">TopTour</h3>
                <p className="text-sm text-muted-foreground">Zážitky v prírode</p>
              </a>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default ContactPage;