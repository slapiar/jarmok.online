import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Newspaper } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ArticleCard from '@/components/ArticleCard.jsx';
import { Skeleton } from '@/components/ui/skeleton';

const CampaignPage = () => {
  const { campaignSlug } = useParams();
  const [campaign, setCampaign] = useState(null);
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const campaignData = await pb.collection('campaigns').getFirstListItem(
          `slug="${campaignSlug}"`,
          { $autoCancel: false }
        );
        setCampaign(campaignData);

        const articlesData = await pb.collection('articles').getFullList({
          filter: `campaign_id="${campaignData.id}"`,
          sort: '-created',
          expand: 'campaign_id',
          $autoCancel: false
        });
        setArticles(articlesData);
      } catch (error) {
        console.error('Error fetching campaign data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [campaignSlug]);

  if (loading) {
    return (
      <>
        <Header />
        <main className="min-h-screen">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <Skeleton className="h-32 w-full rounded-2xl mb-8" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Skeleton key={i} className="h-80 w-full rounded-xl" />
              ))}
            </div>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  if (!campaign) {
    return (
      <>
        <Header />
        <main className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-3xl font-display font-bold mb-4">Kampaň nenájdená</h1>
            <p className="text-muted-foreground">Táto kampaň neexistuje.</p>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>{`${campaign.name} | jarmok.online`}</title>
        <meta
          name="description"
          content={campaign.description || `Všetky články z kampane ${campaign.name}`}
        />
      </Helmet>

      <Header />

      <main className="min-h-screen">
        <section
          className="py-20"
          style={{
            background: `linear-gradient(135deg, ${campaign.color}15 0%, transparent 100%)`
          }}
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-4 mb-6">
              <span
                className="text-5xl w-20 h-20 rounded-2xl flex items-center justify-center"
                style={{ backgroundColor: `${campaign.color}20` }}
              >
                {campaign.icon}
              </span>
              <div>
                <h1 className="text-4xl md:text-5xl font-display font-bold leading-tight" style={{ letterSpacing: '-0.02em' }}>
                  {campaign.name}
                </h1>
                {campaign.description && (
                  <p className="text-lg text-muted-foreground mt-2 leading-relaxed">
                    {campaign.description}
                  </p>
                )}
              </div>
            </div>
            <p className="text-muted-foreground">
              {articles.length} {articles.length === 1 ? 'článok' : articles.length < 5 ? 'články' : 'článkov'}
            </p>
          </div>
        </section>

        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {articles.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {articles.map((article) => (
                <ArticleCard
                  key={article.id}
                  article={article}
                  campaign={campaign}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <Newspaper className="h-16 w-16 text-muted-foreground/50 mx-auto mb-4" />
              <h3 className="text-xl font-display font-semibold mb-2">Zatiaľ žiadne články</h3>
              <p className="text-muted-foreground">V tejto kampani ešte neboli publikované žiadne články.</p>
            </div>
          )}
        </section>
      </main>

      <Footer />
    </>
  );
};

export default CampaignPage;