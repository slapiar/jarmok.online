import { useCallback } from 'react';

export const useRelativeTime = () => {
  const getRelativeTime = useCallback((dateString) => {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);
    
    if (diffInSeconds < 60) {
      return 'pred chvíľou';
    }
    
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    if (diffInMinutes < 60) {
      if (diffInMinutes === 1) return 'pred 1 minútou';
      if (diffInMinutes >= 2 && diffInMinutes <= 4) return `pred ${diffInMinutes} minútami`;
      return `pred ${diffInMinutes} minútami`;
    }
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) {
      if (diffInHours === 1) return 'pred 1 hodinou';
      if (diffInHours >= 2 && diffInHours <= 4) return `pred ${diffInHours} hodinami`;
      return `pred ${diffInHours} hodinami`;
    }
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays === 1) {
      return 'včera';
    }
    if (diffInDays < 7) {
      return `pred ${diffInDays} dňami`;
    }
    
    const diffInWeeks = Math.floor(diffInDays / 7);
    if (diffInWeeks === 1) {
      return 'minulý týždeň';
    }
    if (diffInWeeks < 4) {
      return `pred ${diffInWeeks} týždňami`;
    }
    
    const diffInMonths = Math.floor(diffInDays / 30);
    if (diffInMonths === 1) {
      return 'minulý mesiac';
    }
    if (diffInMonths < 12) {
      if (diffInMonths >= 2 && diffInMonths <= 4) return `pred ${diffInMonths} mesiacmi`;
      return `pred ${diffInMonths} mesiacmi`;
    }
    
    const diffInYears = Math.floor(diffInDays / 365);
    if (diffInYears === 1) return 'minulý rok';
    if (diffInYears >= 2 && diffInYears <= 4) return `pred ${diffInYears} rokmi`;
    return `pred ${diffInYears} rokmi`;
  }, []);

  return getRelativeTime;
};