import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop.jsx';
import HomePage from './pages/HomePage.jsx';
import CampaignPage from './pages/CampaignPage.jsx';
import ArticleDetailPage from './pages/ArticleDetailPage.jsx';
import ContactPage from './pages/ContactPage.jsx';
import UpdatesArchive from './pages/UpdatesArchive.jsx';
import { Toaster } from '@/components/ui/sonner';

function App() {
  return (
    <Router>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/kampane/:campaignSlug" element={<CampaignPage />} />
        <Route path="/clanok/:articleSlug" element={<ArticleDetailPage />} />
        <Route path="/kontakt" element={<ContactPage />} />
        <Route path="/aktuality" element={<UpdatesArchive />} />
      </Routes>
      <Toaster />
    </Router>
  );
}

export default App;