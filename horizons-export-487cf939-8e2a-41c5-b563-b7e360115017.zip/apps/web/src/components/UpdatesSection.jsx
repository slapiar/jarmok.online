import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Activity } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import UpdatesList from './UpdatesList.jsx';

const UpdatesSection = () => {
  const [updates, setUpdates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    const fetchLatestUpdates = async () => {
      try {
        const records = await pb.collection('updates').getList(1, 4, {
          sort: '-published_at,-created',
          filter: 'status="published"',
          $autoCancel: false
        });
        setUpdates(records.items);
      } catch (err) {
        console.error('Error fetching updates:', err);
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    fetchLatestUpdates();
  }, []);

  return (
    <section className="py-16 bg-muted/30 border-y border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Activity className="h-5 w-5 text-primary" />
              <h2 className="text-2xl font-display font-bold">Čo je nové v ekosystéme</h2>
            </div>
            <p className="text-muted-foreground">Najnovšie zmeny, produkty a články z našich platforiem.</p>
          </div>
          <Link 
            to="/aktuality" 
            className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
          >
            Pozri všetky aktuality
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="lg:col-span-2">
            <UpdatesList updates={updates} loading={loading} error={error} />
          </div>
        </div>
      </div>
    </section>
  );
};

export default UpdatesSection;