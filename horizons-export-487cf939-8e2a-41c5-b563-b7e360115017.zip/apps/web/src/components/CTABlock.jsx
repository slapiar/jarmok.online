import React from 'react';
import { ExternalLink, BookOpen, ShoppingBag, Mail, Compass } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CTABlock = ({ ctaBlock }) => {
  const getIcon = (type) => {
    switch (type) {
      case 'learn_more':
        return <BookOpen className="h-5 w-5" />;
      case 'shop':
        return <ShoppingBag className="h-5 w-5" />;
      case 'contact':
        return <Mail className="h-5 w-5" />;
      case 'experience':
        return <Compass className="h-5 w-5" />;
      default:
        return <ExternalLink className="h-5 w-5" />;
    }
  };

  const isExternal = ctaBlock.button_url.startsWith('http');

  return (
    <div className="bg-accent rounded-xl p-6 border border-border">
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
          {getIcon(ctaBlock.type)}
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-display font-semibold mb-2">{ctaBlock.title}</h3>
          {ctaBlock.description && (
            <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
              {ctaBlock.description}
            </p>
          )}
          {isExternal ? (
            <a
              href={ctaBlock.button_url}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button className="w-full sm:w-auto transition-all duration-200">
                {ctaBlock.button_text}
                <ExternalLink className="ml-2 h-4 w-4" />
              </Button>
            </a>
          ) : (
            <a href={ctaBlock.button_url}>
              <Button className="w-full sm:w-auto transition-all duration-200">
                {ctaBlock.button_text}
              </Button>
            </a>
          )}
        </div>
      </div>
    </div>
  );
};

export default CTABlock;