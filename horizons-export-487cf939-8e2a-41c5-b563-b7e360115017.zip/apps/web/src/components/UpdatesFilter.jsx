import React from 'react';
import { Button } from '@/components/ui/button';

const UpdatesFilter = ({ currentFilter, onFilterChange }) => {
  const filters = [
    { id: 'all', label: 'Všetko' },
    { id: 'high_significance', label: 'Len dôležité' },
    { id: 'source_shop', label: '🛍️ Shop' },
    { id: 'source_kb', label: '📚 Znalosti' },
    { id: 'source_drfyto', label: '🌍 Drfyto' },
    { id: 'source_toptour', label: '🎪 TopTour' },
    { id: 'type_new', label: 'Nové' },
    { id: 'type_updated', label: 'Aktualizované' }
  ];

  return (
    <div className="flex flex-wrap gap-2 mb-8">
      {filters.map((filter) => (
        <Button
          key={filter.id}
          variant={currentFilter === filter.id ? "default" : "outline"}
          size="sm"
          onClick={() => onFilterChange(filter.id)}
          className="rounded-full transition-all duration-200"
        >
          {filter.label}
        </Button>
      ))}
    </div>
  );
};

export default UpdatesFilter;