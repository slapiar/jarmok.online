import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import ArticleCard from './ArticleCard.jsx';

const CampaignBlock = ({ campaign, articles }) => {
  return (
    <section className="py-12">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <span
            className="text-4xl w-16 h-16 rounded-xl flex items-center justify-center"
            style={{ backgroundColor: `${campaign.color}20` }}
          >
            {campaign.icon}
          </span>
          <div>
            <h2 className="text-2xl md:text-3xl font-display font-bold">{campaign.name}</h2>
            {campaign.description && (
              <p className="text-muted-foreground mt-1">{campaign.description}</p>
            )}
          </div>
        </div>
        <Link
          to={`/kampane/${campaign.slug}`}
          className="hidden sm:inline-flex items-center gap-2 text-primary font-medium hover:gap-3 transition-all duration-200"
        >
          Pozri všetko
          <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {articles.slice(0, 3).map((article) => (
          <ArticleCard key={article.id} article={article} campaign={campaign} />
        ))}
      </div>

      <Link
        to={`/kampane/${campaign.slug}`}
        className="sm:hidden inline-flex items-center gap-2 text-primary font-medium hover:gap-3 transition-all duration-200 mt-6"
      >
        Pozri všetko
        <ArrowRight className="h-4 w-4" />
      </Link>
    </section>
  );
};

export default CampaignBlock;