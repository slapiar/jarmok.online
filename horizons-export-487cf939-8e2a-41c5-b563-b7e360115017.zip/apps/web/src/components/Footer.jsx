import React from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';

const Footer = () => {
  const externalLinks = [
    { name: 'Jarmok Shop', url: 'https://jarmok.shop' },
    { name: 'Knowledge Base', url: 'https://kb.drfyto.com' },
    { name: 'Dr. Fyto', url: 'https://drfyto.com' },
    { name: 'TopTour', url: 'https://toptour.sk' }
  ];

  return (
    <footer className="bg-primary text-primary-foreground mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-display font-bold mb-4">jarmok.online</h3>
            <p className="text-primary-foreground/80 leading-relaxed">
              Digitálne noviny ekosystému pre udržateľný život v harmónii s prírodou.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-display font-semibold mb-4">Naše platformy</h4>
            <ul className="space-y-2">
              {externalLinks.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-primary-foreground/80 hover:text-primary-foreground transition-colors duration-200"
                  >
                    {link.name}
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-display font-semibold mb-4">Kontakt</h4>
            <ul className="space-y-2">
              <li>
                <Link
                  to="/kontakt"
                  className="text-primary-foreground/80 hover:text-primary-foreground transition-colors duration-200"
                >
                  Kontaktný formulár
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-primary-foreground/20 text-center text-sm text-primary-foreground/60">
          <p>&copy; {new Date().getFullYear()} jarmok.online. Všetky práva vyhradené.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;