import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';

const ArticleCard = ({ article, campaign, variant = 'default' }) => {
  const imageUrl = article.featured_image
    ? pb.files.getUrl(article, article.featured_image)
    : null;

  if (variant === 'featured') {
    return (
      <Link
        to={`/clanok/${article.slug}`}
        className="group block bg-card rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300"
      >
        <div className="grid md:grid-cols-2 gap-0">
          {imageUrl && (
            <div className="relative h-64 md:h-full overflow-hidden">
              <img
                src={imageUrl}
                alt={article.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>
          )}
          <div className="p-8 flex flex-col justify-center">
            {campaign && (
              <span
                className="inline-block px-3 py-1 text-xs font-semibold rounded-full mb-4 w-fit"
                style={{
                  backgroundColor: `${campaign.color}20`,
                  color: campaign.color
                }}
              >
                {campaign.icon} {campaign.name}
              </span>
            )}
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4 leading-tight group-hover:text-primary transition-colors duration-200">
              {article.title}
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6">
              {article.excerpt}
            </p>
            <span className="inline-flex items-center gap-2 text-primary font-medium group-hover:gap-3 transition-all duration-200">
              Čítať viac
              <ArrowRight className="h-4 w-4" />
            </span>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link
      to={`/clanok/${article.slug}`}
      className="group block bg-card rounded-xl overflow-hidden border border-border hover:shadow-lg transition-all duration-300"
    >
      {imageUrl && (
        <div className="relative h-48 overflow-hidden">
          <img
            src={imageUrl}
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
      )}
      <div className="p-6">
        {campaign && (
          <span
            className="inline-block px-2 py-1 text-xs font-semibold rounded-full mb-3"
            style={{
              backgroundColor: `${campaign.color}20`,
              color: campaign.color
            }}
          >
            {campaign.icon} {campaign.name}
          </span>
        )}
        <h3 className="text-xl font-display font-bold mb-2 leading-snug group-hover:text-primary transition-colors duration-200">
          {article.title}
        </h3>
        <p className="text-sm text-muted-foreground leading-relaxed mb-4 line-clamp-2">
          {article.excerpt}
        </p>
        <span className="inline-flex items-center gap-2 text-sm text-primary font-medium group-hover:gap-3 transition-all duration-200">
          Čítať viac
          <ArrowRight className="h-4 w-4" />
        </span>
      </div>
    </Link>
  );
};

export default ArticleCard;