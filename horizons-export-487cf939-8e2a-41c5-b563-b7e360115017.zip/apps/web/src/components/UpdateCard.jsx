import React from 'react';
import { ShoppingBag, BookOpen, Globe, Compass, ExternalLink } from 'lucide-react';
import { useRelativeTime } from '@/hooks/useRelativeTime.js';

const UpdateCard = ({ update }) => {
  const formatRelativeTime = useRelativeTime();

  const getSourceConfig = (source) => {
    switch (source) {
      case 'shop':
        return { icon: <ShoppingBag className="h-4 w-4" />, label: 'Jarmok Shop', color: 'text-emerald-600', bg: 'bg-emerald-600/10' };
      case 'kb':
        return { icon: <BookOpen className="h-4 w-4" />, label: 'Znalostná báza', color: 'text-blue-600', bg: 'bg-blue-600/10' };
      case 'drfyto':
        return { icon: <Globe className="h-4 w-4" />, label: 'Dr. Fyto', color: 'text-amber-600', bg: 'bg-amber-600/10' };
      case 'toptour':
        return { icon: <Compass className="h-4 w-4" />, label: 'TopTour', color: 'text-rose-600', bg: 'bg-rose-600/10' };
      default:
        return { icon: <Globe className="h-4 w-4" />, label: 'Neznámy zdroj', color: 'text-muted-foreground', bg: 'bg-muted' };
    }
  };

  const sourceConfig = getSourceConfig(update.source);

  return (
    <a 
      href={update.source_url || update.canonical_url || '#'} 
      target="_blank" 
      rel="noopener noreferrer"
      className="group block bg-card rounded-xl p-5 border border-border hover:shadow-md transition-all duration-200 relative overflow-hidden"
    >
      <div className="flex items-start gap-4">
        <div className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center ${sourceConfig.bg} ${sourceConfig.color}`}>
          {sourceConfig.icon}
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className={`text-xs font-medium ${sourceConfig.color}`}>
              {sourceConfig.label}
            </span>
            <span className="text-muted-foreground text-xs">•</span>
            <span className="text-muted-foreground text-xs">
              {formatRelativeTime(update.published_at || update.detected_at || update.created)}
            </span>
            {update.significance_level === 'high' && (
              <>
                <span className="text-muted-foreground text-xs">•</span>
                <span className="text-destructive text-xs font-medium">Dôležité</span>
              </>
            )}
          </div>
          
          <h3 className="text-base font-semibold text-foreground group-hover:text-primary transition-colors duration-200 mb-2 leading-snug pr-6">
            {update.title}
          </h3>
          
          {update.excerpt && (
            <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">
              {update.excerpt}
            </p>
          )}
        </div>
      </div>
      
      <div className="absolute top-5 right-5 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <ExternalLink className="h-4 w-4 text-muted-foreground" />
      </div>
    </a>
  );
};

export default UpdateCard;