import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  const campaigns = [
    { name: 'Tajomstvo lesov a lúk', slug: 'tajomstvo-lesov-a-luk' },
    { name: 'Káva inak', slug: 'kava-inak' },
    { name: 'Bez odpadu', slug: 'bez-odpadu' },
    { name: 'Staň sa partnerom', slug: 'stan-sa-partnerom' }
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <span className="text-2xl font-display font-bold text-primary">jarmok.online</span>
          </Link>

          <nav className="hidden md:flex items-center space-x-1">
            {campaigns.map((campaign) => (
              <Link
                key={campaign.slug}
                to={`/kampane/${campaign.slug}`}
                className={`px-3 py-2 text-sm font-medium rounded-lg transition-all duration-200 ${
                  isActive(`/kampane/${campaign.slug}`)
                    ? 'bg-primary text-primary-foreground'
                    : 'text-foreground hover:bg-muted'
                }`}
              >
                {campaign.name}
              </Link>
            ))}
            <Link
              to="/kontakt"
              className={`px-3 py-2 text-sm font-medium rounded-lg transition-all duration-200 ${
                isActive('/kontakt')
                  ? 'bg-primary text-primary-foreground'
                  : 'text-foreground hover:bg-muted'
              }`}
            >
              Kontakt
            </Link>
          </nav>

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>

        {mobileMenuOpen && (
          <nav className="md:hidden py-4 space-y-2 border-t border-border">
            {campaigns.map((campaign) => (
              <Link
                key={campaign.slug}
                to={`/kampane/${campaign.slug}`}
                onClick={() => setMobileMenuOpen(false)}
                className={`block px-3 py-2 text-base font-medium rounded-lg transition-all duration-200 ${
                  isActive(`/kampane/${campaign.slug}`)
                    ? 'bg-primary text-primary-foreground'
                    : 'text-foreground hover:bg-muted'
                }`}
              >
                {campaign.name}
              </Link>
            ))}
            <Link
              to="/kontakt"
              onClick={() => setMobileMenuOpen(false)}
              className={`block px-3 py-2 text-base font-medium rounded-lg transition-all duration-200 ${
                isActive('/kontakt')
                  ? 'bg-primary text-primary-foreground'
                  : 'text-foreground hover:bg-muted'
              }`}
            >
              Kontakt
            </Link>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;