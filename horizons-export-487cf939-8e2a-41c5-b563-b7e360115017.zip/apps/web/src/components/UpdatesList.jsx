import React from 'react';
import UpdateCard from './UpdateCard.jsx';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertCircle, Inbox } from 'lucide-react';

const UpdatesList = ({ updates, loading, error }) => {
  if (error) {
    return (
      <div className="bg-destructive/10 text-destructive rounded-xl p-6 flex items-center gap-3">
        <AlertCircle className="h-5 w-5" />
        <p className="font-medium">Chyba pri načítaní aktualít. Prosím, skúste to neskôr.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="bg-card rounded-xl p-5 border border-border flex gap-4">
            <Skeleton className="w-10 h-10 rounded-lg flex-shrink-0" />
            <div className="flex-1 space-y-3">
              <Skeleton className="h-3 w-32" />
              <Skeleton className="h-5 w-3/4" />
              <Skeleton className="h-4 w-full" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!updates || updates.length === 0) {
    return (
      <div className="text-center py-16 bg-muted/30 rounded-2xl border border-dashed border-border">
        <Inbox className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-foreground mb-1">Žiadne aktuality</h3>
        <p className="text-muted-foreground text-sm">Pre zvolený filter sa nenašli žiadne záznamy.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {updates.map((update) => (
        <UpdateCard key={update.id} update={update} />
      ))}
    </div>
  );
};

export default UpdatesList;