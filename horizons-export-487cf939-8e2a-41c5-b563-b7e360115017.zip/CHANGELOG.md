# Changelog

## [0.1.1] - 2026-04-12

### Type
PATCH

### Summary
Refactored hardcoded API endpoints and RSS feeds into centralized configuration system. Added source enable/disable flags and placeholder status tracking for endpoints awaiting real API confirmation.

### Modified Files
- `apps/api/src/connectors/sourceConnectors.js` - Refactored to use SOURCES_CONFIG, added source enable checks, improved logging with emoji prefixes and Slovak messages
- `apps/api/src/parsers/sourceParsers.js` - Added defensive parsing with fallback structures, improved error handling and logging
- `apps/api/src/schedulers/updatesSyncScheduler.js` - Added configuration checks, improved logging with emoji prefixes and Slovak messages

### New Files
- `apps/api/src/config/sources.config.js` - Centralized configuration for all 4 sources (shop, kb, drfyto, toptour) with endpoint definitions and helper functions
- `CHANGELOG.md` - This file

### Changes
1. **Configuration Management**: Moved all hardcoded API endpoints and RSS feeds to `sources.config.js`
2. **Source Enable/Disable**: Added `enabled` flag to each source for easy toggling
3. **Endpoint Status Tracking**: All endpoints marked as `placeholder` with comments indicating we're waiting for real API confirmation
4. **Helper Functions**: Exported `getSourceConfig()`, `isSourceEnabled()`, `isEndpointPlaceholder()`, and `getEndpointConfig()` for easy access
5. **Improved Logging**: Added emoji prefixes (✓, ✗, ⚠️, ℹ️) and Slovak messages throughout for better visibility
6. **Defensive Parsing**: Added fallback structures and better error handling in parsers
7. **Source Validation**: Added checks to skip disabled sources and warn about placeholder endpoints

### Risks
**LOW** - Changes are localized to configuration and logging layers. No changes to core sync workflow or data processing logic.

### Next Steps
1. **Discover Real APIs**: Contact each source provider to confirm real API/RSS endpoints
2. **Update Configuration**: Once confirmed, update `sources.config.js` with real URLs and change status from `placeholder` to `confirmed`
3. **Implement v0.1.2**: Add scraping implementations for sources that don't have API/RSS feeds
4. **Testing**: Test each source with real endpoints before marking as production-ready